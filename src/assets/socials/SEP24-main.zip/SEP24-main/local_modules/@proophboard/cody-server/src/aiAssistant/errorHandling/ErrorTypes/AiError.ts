export class AiError extends Error {
	constructor(message: string) {
		super(message);
		this.name = 'AiError';
		Error.captureStackTrace(this, AiError);
	}
}

export class AiRequestError extends AiError {
	constructor(message: string) {
		super(message);
		this.name = 'AiRequestError';
		Error.captureStackTrace(this, AiRequestError);
	}
}

export class AiCredentialsError extends AiRequestError {
	constructor(message: string) {
		super(message);
		this.name = 'AiRequestCredentialsError';
		Error.captureStackTrace(this, AiCredentialsError);
	}
}

export class AiOverloadError extends AiRequestError {
	constructor(message: string) {
		super(message);
		this.name = 'AiOverloadError';
		Error.captureStackTrace(this, AiOverloadError);
	}
}

export class AiTimeoutError extends AiError {
	constructor(message: string) {
		super(message);
		this.name = 'AiTimeoutError';
		Error.captureStackTrace(this, AiRequestError);
	}
}

export class AiResponseError extends AiError {
	constructor(message: string) {
		super(message);
		this.name = 'AiResponseError';
		Error.captureStackTrace(this, AiResponseError);
	}
}

export class PromptGenerationError extends AiError {
	constructor(message: string) {
		super(message);
		this.name = 'RequestError';
		Error.captureStackTrace(this, PromptGenerationError);
	}
}

export class GetMetaDataError extends PromptGenerationError {
	constructor(message: string) {
		super(message);
		this.name = 'GetMetaDataError';
		Error.captureStackTrace(this, GetMetaDataError);
	}
}
