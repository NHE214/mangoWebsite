import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';
export declare class AnyFilter implements Filter {
    processWith(processor: FilterProcessor): any;
}
