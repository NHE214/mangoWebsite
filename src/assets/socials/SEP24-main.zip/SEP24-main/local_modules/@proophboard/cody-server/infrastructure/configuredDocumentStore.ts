import {DocumentStore} from "./DocumentStore";
import {PostgresDocumentStore} from "./DocumentStore/PostgresDocumentStore";
import {getConfiguredDB} from "./configuredDB";
import {InMemoryDocumentStore} from "./DocumentStore/InMemoryDocumentStore";
import {env} from "../environments/environment.current";

let store: DocumentStore;

const path = process.cwd() === '/app' ? '/data' : '/../../data';

export const PERSISTENT_COLLECTION_FILE = process.cwd() + path + '/persistent-collections.json';

export const getConfiguredDocumentStore = (): DocumentStore => {
  if(!store) {
    switch (env.documentStore.adapter) {
      case "postgres":
        store = new PostgresDocumentStore(getConfiguredDB());
        break;
      case "filesystem":
        store = new InMemoryDocumentStore(PERSISTENT_COLLECTION_FILE);
        break;
      default:
        store = new InMemoryDocumentStore();
    }
  }

  return store;
}
