export class CommandError extends Error {
	constructor(message: string) {
		super(message);
		this.name = 'CommandError';
		Error.captureStackTrace(this, CommandError);
	}
}

export class CommandNotFoundError extends CommandError {
	constructor(message: string) {
		super(message);
		this.name = 'CommandNotFoundError';
		Error.captureStackTrace(this, CommandNotFoundError);
	}
}
