import { chatMode, Commands, setCodyAnswer } from './commandHandler';
import { addCardExtended, addCardNextId, connectElementsByID, getNameById } from './cardHandler';
import { getCodyConfig } from '../http/question';
import { contactAI, parseAiResponse, setOngoingConversation } from './aiInteraction';
import { deleteAllConversations } from './databaseInteraction';
import { generatePrompt } from './promptGenerator';
import {
	CardsWithoutPositionList,
	CardWithoutPosition,
	EntityDecision,
	InputValidation,
	MetaDataDecision,
	SystemDescription,
} from './types';
import { GraphPoint } from '@proophboard/cody-types';
import { generateMetaData } from './cardGenerator';

export enum SystemOperations {
	add = 'add',
	edit = 'edit',
	delete = 'delete',
}

/**
 * parses value pairs name/type for suggested cards and creates system by calling cardHandler.ts
 * additionally connects cards by order (given in primerText) and adds metadata according to type
 * @param response
 * @param offset
 */
export async function systemCreate(response: string, offset: GraphPoint = { x: 0, y: 0 }) {
	let prompt = await generatePrompt({ command: Commands.create, response: response });
	const isValidInputString = await isValidRequest(prompt.introduction);

	if (isValidInputString[0] === 'correct') {
		let writeCardsRaw = await contactAI(prompt.JSONConversion);
		const writeCards = parseAiResponse<CardsWithoutPositionList>(writeCardsRaw);
		console.log('......................... Debug 3 ........................... write cards:', writeCards);

		let addCount = 0;
		let predecessor: string = '';
		let connectorArray: string[] = [];

		let informationObject: CardWithoutPosition = { name: '', type: '' };
		let informationList: CardWithoutPosition = { name: '', type: '' };
		setCodyAnswer('Generate system of cards: \n');
		setCodyAnswer(`input: "${response}"\n`);

		for (const elements of writeCards.cards) {
			if (addCount === 0) {
				predecessor = await addCardExtended(elements.name, elements.type, offset);
				informationObject = { name: elements.name, type: elements.type };
				connectorArray.push(predecessor);
				setCodyAnswer(`Object: ${elements.name}\n`);
				addCount++;
				await buyingTime();
			} else if (addCount === 1) {
				predecessor = await addCardNextId(predecessor, elements.name, elements.type);
				informationList = { name: elements.name, type: elements.type };
				connectorArray.push(predecessor);
				addCount++;
				await buyingTime();
			} else {
				predecessor = await addCardNextId(predecessor, elements.name, elements.type);
				connectorArray.push(predecessor);
				await buyingTime();
			}
		}
		console.log('......................... Debug 4 ........................... write last cards');

		predecessor = await addCardNextId(predecessor, informationObject.name, informationObject.type);
		await buyingTime();
		connectorArray.push(predecessor);

		predecessor = await addCardNextId(predecessor, informationList.name, informationList.type);
		await buyingTime();
		connectorArray.push(predecessor);

		console.log('......................... Debug 5 ........................... connect cards');

		for (let j = 0; j < connectorArray.length - 1; j++) {
			await buyingTime(500);
			await connectElementsByID(connectorArray[j], connectorArray[j + 1]);
		}
		console.log('......................... Debug 6 ........................... write metaData');

		let typeDecision: string = await contactAI(prompt.metaDecision);
		const operation: SystemOperations = parseAiResponse<MetaDataDecision>(typeDecision).type;
		console.log('............................................................. option: ', operation);
		setCodyAnswer(`Operation: ${operation}\n\n`);

		await addMetaData(connectorArray, operation);
		await buyingTime(5000);
	} else {
		setCodyAnswer(`\n[Create]: Provided input sentence cannot be processed:\n"${response}"\n`);
	}
}

/**
 * waits for a given amount of time in ms (or defaults to 1000ms)
 * @param time
 */
export async function buyingTime(time: number = 1000) {
	return new Promise(resolve => setTimeout(resolve, time));
}

/**
 * creates the actual metaData for added cards according to their type and option (add, delete or edit operation)
 * @param idArray
 * @param systemOperation
 */
async function addMetaData(idArray: string[] | any[], systemOperation: SystemOperations) {
	let config = await getCodyConfig();

	let title: string = await getNameById(idArray[0]);

	for (let k = 0; k < idArray.length - 1; k++) {
		config.context.syncedNodes.forEach(node => {
			if (node.getId() === idArray[k]) {
				generateMetaData(title, idArray[k], systemOperation);
				buyingTime(500);
			}
		});
		await buyingTime(500);
	}
	await buyingTime();
}

/**
 * create all 3 system add,delete,edit for a single input sentence
 * @param response
 */
export async function eventsCreate(response: string) {
	let prompt = await generatePrompt({ command: Commands.createPlus, response: response });
	const isValidInputString = await isValidRequest(prompt.introduction);

	if (isValidInputString[0] === 'correct') {
		setOngoingConversation([]);
		await deleteAllConversations();
		let eventsRaw = await contactAI(prompt.entityCreation);
		const events = parseAiResponse<EntityDecision>(eventsRaw).name;

		prompt = await generatePrompt({ command: Commands.createPlus, response: response, cards: events });
		let sentencesRaw = await contactAI(prompt.systemDescription);
		const sentenceArray = parseAiResponse<SystemDescription>(sentencesRaw);
		console.log('............................................... sentences: ', sentenceArray);

		let offset: GraphPoint = { x: 0, y: 300 };
		let offset2: GraphPoint = { x: 0, y: 600 };
		let count: number = 0;
		for (const singleSentence of sentenceArray) {
			await deleteAllConversations();
			setOngoingConversation([]);
			if (count === 0) {
				await chatMode(prompt.cardCreation);
				await systemCreate(singleSentence.sentence);
				count++;
			} else if (count === 1) {
				await chatMode(prompt.cardCreation);
				await systemCreate(singleSentence.sentence, offset);
				count++;
			} else {
				await chatMode(prompt.cardCreation);
				await systemCreate(singleSentence.sentence, offset2);
			}
		}
	} else {
		setCodyAnswer(`\n[createPlus]: Provided input sentence cannot be processed:\n"${response}"\n`);
	}
}

/**
 * create systems of add,delete,edit for various AI suggested entities
 * @param response
 */
export async function eventsMultiCreate(response: string) {
	let prompt = await generatePrompt({ command: Commands.multiCreate, response: response });
	const isValidInputString = await isValidRequest(prompt.introduction);

	if (isValidInputString[0] === 'correct') {
		setOngoingConversation([]);
		await deleteAllConversations();
		let multiRaw = await contactAI(prompt.entityCreation);
		const multi = parseAiResponse<EntityDecision[]>(multiRaw);
		console.log('............................................... multi: ', multi);
		setCodyAnswer('Suggested parties necessary for the requested system are: \n');
		let offset0: GraphPoint = { x: 0, y: 0 };
		let offset: GraphPoint = { x: 0, y: 300 };
		let offset2: GraphPoint = { x: 0, y: 600 };
		let addCount: number = 0;

		for (const suggestion of multi) {
			prompt = await generatePrompt({
				command: Commands.multiCreate,
				response: response,
				cards: suggestion.name,
			});
			setOngoingConversation([]);
			await deleteAllConversations();
			let sentencesRaw = await contactAI(prompt.systemDescription);
			const sentenceArray = parseAiResponse<SystemDescription>(sentencesRaw);
			console.log('............................................... sentences: ', sentenceArray);
			setCodyAnswer('\nGenerated standard add, delete and edit functions for involved parties.\n');

			for (const singleSentence of sentenceArray) {
				await deleteAllConversations();
				setOngoingConversation([]);
				if (addCount === 0) {
					await chatMode(prompt.JSONConversion);
					await systemCreate(singleSentence.sentence, offset0);
					addCount++;
				} else if (addCount === 1) {
					await chatMode(prompt.JSONConversion);
					await systemCreate(singleSentence.sentence, offset);
					addCount++;
				} else {
					await chatMode(prompt.JSONConversion);
					await systemCreate(singleSentence.sentence, offset2);
				}
			}

			offset0.y += 1000;
			offset.y += 1000;
			offset2.y += 1000;
			addCount = 0;
		}
		setCodyAnswer(`Cards for suggested entities have been created:\n${multi}`);
	} else {
		setCodyAnswer(`\n[multiCreate]: Provided input sentence cannot be processed:\n"${response}"\n`);
	}
}

/**
 *
 * @param validationPrompt
 */
async function isValidRequest(validationPrompt: string) {
	let isValidInput = await contactAI(validationPrompt);
	return parseAiResponse<InputValidation>(isValidInput);
}
