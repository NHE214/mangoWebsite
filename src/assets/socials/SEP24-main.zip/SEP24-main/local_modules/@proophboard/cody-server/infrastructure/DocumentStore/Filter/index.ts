import { EqFilter } from './EqFilter';
import { AnyFilter } from './AnyFilter';
import { AndFilter } from './AndFilter';
import { OrFilter } from './OrFilter';
import { DocIdFilter } from './DocIdFilter';
import { ExistsFilter } from './ExistsFilter';
import { GtFilter } from './GtFilter';
import { GteFilter } from './GteFilter';
import { LteFilter } from './LteFilter';
import { InArrayFilter } from './InArrayFilter';
import { LikeFilter } from './LikeFilter';
import { NotFilter } from './NotFilter';
import { AnyOfDocIdFilter } from './AnyOfDocIdFilter';
import { AnyOfFilter } from './AnyOfFilter';
import { LtFilter } from './LtFilter';

export const filters = {
	AndFilter: AndFilter,
	AnyFilter: AnyFilter,
	AnyOfDocIdFilter: AnyOfDocIdFilter,
	AnyOfFilter: AnyOfFilter,
	DocIdFilter: DocIdFilter,
	EqFilter: EqFilter,
	ExistsFilter: ExistsFilter,
	GteFilter: GteFilter,
	GtFilter: GtFilter,
	InArrayFilter: InArrayFilter,
	LikeFilter: LikeFilter,
	LteFilter: LteFilter,
	LtFilter: LtFilter,
	NotFilter: NotFilter,
	OrFilter: OrFilter,
};
