export declare class HandleCardError extends Error {
    constructor(message: string);
}
export declare class CardPositioningError extends HandleCardError {
    constructor(message: string);
}
export declare class ProophboardAPIError extends HandleCardError {
    constructor(message: string);
}
export declare class ProophboardAPICredentialsError extends ProophboardAPIError {
    constructor(message: string);
}
export declare class MetadataError extends HandleCardError {
    constructor(message: string);
}
export declare class NodeParameterError extends HandleCardError {
    constructor(message: string);
}
export declare class CodyTypeError extends NodeParameterError {
    constructor(message: string);
}
export declare class RelativeDirectionError extends NodeParameterError {
    constructor(message: string);
}
export declare class CardNotFoundError extends HandleCardError {
    constructor(message: string);
}
