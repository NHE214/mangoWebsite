import { CodyResponse } from "@proophboard/cody-types";
export declare const greeting: (user: string) => CodyResponse;
export interface IioSaidHello {
    user: string;
}
