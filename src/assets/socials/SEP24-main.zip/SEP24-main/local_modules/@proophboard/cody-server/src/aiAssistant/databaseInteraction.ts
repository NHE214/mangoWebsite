import { CodyResponseType } from '@proophboard/cody-types';
import { handleCommand } from './commandHandler';
import { getOngoingConversation, setOngoingConversation } from './aiInteraction';
import { AnyFilter } from '../../infrastructure/DocumentStore/Filter/AnyFilter';
import { Filter } from '../../infrastructure/DocumentStore/Filter';
import { getConfiguredDocumentStore } from '../../infrastructure/configuredDocumentStore';

const filter: Filter = new AnyFilter();
const collectionName: string = 'conversations';
let store = getConfiguredDocumentStore();
let documentId = 1;

/**
 * Tests the availability of the MongoDB database.
 * @returns {Promise<boolean>} A promise that resolves with a boolean indicating database availability.
 */
export async function testDBAvailability(): Promise<boolean> {
	if (!(await store.hasCollection(collectionName))) {
		console.log('creating new Collection');
		await store.addCollection(collectionName);
	}
	return true;
}

/**
 * Saves the ongoing conversation to the posgres database.
 * @returns {Promise<void>} A promise that resolves once the conversation is saved.
 */
export async function saveConversationToDB(): Promise<void> {
	try {
		let id = '';
		id += documentId;
		await store.addDoc(collectionName, id, { conversation: getOngoingConversation() });
		documentId++;
		console.log('Conversation saved');
	} catch (error) {
		console.error('Error saving conversation to database:', error);
		throw error;
	}
}

/**
 * Retrieves the conversation history from the posgres database.
 * @returns {Promise<string>} A promise that resolves with the formatted conversation history.
 */
export async function getConversationHistory(): Promise<string> {
	try {
		const asyncIterable = await store.findDocs(collectionName, filter);

		let formattedHistory = '';

		for await (const [id, conversation] of asyncIterable) {
			console.log(conversation.conversation);
			formattedHistory += `\nConversation ${id}:\n`;
			if (Array.isArray(conversation.conversation)) {
				conversation.conversation.forEach((message: { role: string; content: string }) => {
					formattedHistory += `-${message.role}: "${message.content}"\n`;
				});
			} else {
				console.error(`Invalid conversation format for conversation ${id}`);
			}
		}
		return formattedHistory;
	} catch (error) {
		console.error('Error retrieving conversation history from DocumentStore:', error);
		throw error;
	}
}

/**
 * Deletes all conversation histories from the posgres database.
 * @returns {Promise<void>} A promise that resolves once all conversation histories are deleted.
 */
export async function deleteAllConversations(): Promise<void> {
	try {
		await store.deleteMany(collectionName, filter);
		console.log('All conversation histories deleted successfully.');
	} catch (error) {
		console.error('Error deleting conversation histories from database:', error);
		throw error;
	}
}

/**
 * Loads a specific conversation from the conversation history.
 * @param {number} index - The index of the conversation to load.
 * @returns {Promise<any>} A promise that resolves with the conversation data.
 */
export async function loadConversationHistory(index: number): Promise<any> {
	try {
		if (index < 1 || index > (await store.countDocs(collectionName, filter))) {
			console.error('Invalid conversation history index:', index);
			return;
		}

		function isNumber(value: any) {
			return /^\d+$/.test(value);
		}

		if (isNumber(index)) {
			let id = '';
			id += index;
			let selectedConversation = await store.getDoc(collectionName, id);

			if (selectedConversation) {
				setOngoingConversation(selectedConversation.conversation);
				console.log(getOngoingConversation());
				return {
					cody: `Conversation ${index} selected.`,
					type: CodyResponseType.Question,
					reply: async (yes: string) => {
						return handleCommand(yes);
					},
				};
			}
		} else {
			return {
				cody: 'Alright.',
				type: CodyResponseType.Question,
				reply: async (yes: string) => {
					return handleCommand(yes);
				},
			};
		}
	} catch (error) {
		console.error('Error loading conversation history:', error);
	}
}
