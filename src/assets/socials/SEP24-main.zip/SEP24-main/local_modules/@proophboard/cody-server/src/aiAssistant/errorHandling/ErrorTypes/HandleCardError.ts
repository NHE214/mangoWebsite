export class HandleCardError extends Error {
	constructor(message: string) {
		super(message);
		this.name = 'HandleCardError';
		Error.captureStackTrace(this, HandleCardError);
	}
}

export class CardPositioningError extends HandleCardError {
	constructor(message: string) {
		super(message);
		this.name = 'CardPositioningError';
		Error.captureStackTrace(this, CardPositioningError);
	}
}

export class ProophboardAPIError extends HandleCardError {
	constructor(message: string) {
		super(message);
		this.name = 'ProophboardAPIError';
		Error.captureStackTrace(this, ProophboardAPIError);
	}
}

export class ProophboardAPICredentialsError extends ProophboardAPIError {
	constructor(message: string) {
		super(message);
		this.name = 'ProophboardAPICredentialsError';
		Error.captureStackTrace(this, ProophboardAPICredentialsError);
	}
}

export class MetadataError extends HandleCardError {
	constructor(message: string) {
		super(message);
		this.name = 'MetadataError';
		Error.captureStackTrace(this, MetadataError);
	}
}

export class NodeParameterError extends HandleCardError {
	constructor(message: string) {
		super(message);
		this.name = 'NodeParameterError';
		Error.captureStackTrace(this, NodeParameterError);
	}
}

export class CodyTypeError extends NodeParameterError {
	constructor(message: string) {
		super(message);
		this.name = 'CodyTypeError';
		Error.captureStackTrace(this, CodyTypeError);
	}
}

export class RelativeDirectionError extends NodeParameterError {
	constructor(message: string) {
		super(message);
		this.name = 'RelativeDirectionError';
		Error.captureStackTrace(this, RelativeDirectionError);
	}
}

export class CardNotFoundError extends HandleCardError {
	constructor(message: string) {
		super(message);
		this.name = 'CardNotFoundError';
		Error.captureStackTrace(this, CardNotFoundError);
	}
}
