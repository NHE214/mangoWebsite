import { CodyResponse } from '@proophboard/cody-types';
import { CodyConfig } from '../config/codyconfig';
export interface Reply {
    reply: any;
}
export declare function getCodyConfig(): Promise<CodyConfig>;
/**
 * Represents a reply object.
 * @interface Reply
 * @property {any} handleCommand - The reply content.
 */
/**
 * Checks if the response is a question and stores its reply callback.
 * @param {CodyResponse} res - The Cody response object.
 * @returns {CodyResponse} The modified Cody response object.
 */
export declare const checkQuestion: (res: CodyResponse) => CodyResponse;
/**
 * Handles replies to the current question.
 * @param {any} reply - The user's reply.
 * @returns {Promise<CodyResponse>} The response to the user's reply.
 */
export declare const handleReply: (reply: any) => Promise<CodyResponse>;
/**
 * Handles the users reply after the /talk command.
 * From there on, our own reply-function takes over.
 * @param {CodyConfig} config - The configuration object.
 * @returns {CodyResponse} - The prompt, that gives the user our commands as options.
 */
export declare const test: (config: CodyConfig) => CodyResponse;
