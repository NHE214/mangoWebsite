# @proophboard/cody-server

## 0.4.3

### Patch Changes

- Provide build for server fix

## 0.4.2

### Patch Changes

- req context overrides config context

## 0.4.1

### Patch Changes

- Provide build for new server version

## 0.4.0

### Minor Changes

- 7e4cbb7: Populate context with info about board and user

## 0.3.4

### Patch Changes

- Updated response type of metadata utils

## 0.3.3

### Patch Changes

- Update server lib

## 0.3.2

### Patch Changes

- Require a sync by default

## 0.3.1

### Patch Changes

- Fixed default codyconfig.ts to use immutable Map for syncedNodes

## 0.3.0

### Minor Changes

- Moved @types dependencies from dev to main and bumped ts-node version

## 0.2.0

### Minor Changes

- Switched to run server with ts-node and require a codyconfig.ts

### Patch Changes

- Updated dependencies
  - @proophboard/cody-types@0.3.2

## 0.1.1

### Patch Changes

- Fixed copy command

## 0.1.0

### Minor Changes

- First complete version of Cody

## 0.0.5

### Patch Changes

- Updated dependencies
  - @proophboard/cody-types@0.3.0

## 0.0.4

### Patch Changes

- Updated dependencies
  - @proophboard/cody-types@0.2.0

## 0.0.3

### Patch Changes

- Updated dependencies [e3a69c9]
- Updated dependencies [e3a69c9]
  - @proophboard/cody-types@0.1.0
