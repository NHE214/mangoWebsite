import {
	chatMode,
	getCodyAnswer,
	handleCommand,
	resetCodyAnswer,
	setCodyAnswer,
	splitMessage,
} from '@proophboard/cody-server/src/aiAssistant/commandHandler';
import { CodyResponseType } from '@proophboard/cody-types';
import * as question from '@proophboard/cody-server/src/http/question';
import { mockedCodyConfig } from './__mocks__/codyConfig';

describe('Command Handler Tests', () => {
	let mockGetCodyConfig: jest.SpyInstance;

	beforeEach(() => {
		jest.clearAllMocks();
		mockGetCodyConfig = jest.spyOn(question, 'getCodyConfig').mockImplementation(async () => mockedCodyConfig);
	});

	afterEach(() => {
		mockGetCodyConfig.mockRestore();
	});

	it('test /ai -chat command', async () => {
		const repl = '/ai -chat';
		const response = await handleCommand(repl);
		expect(response).toStrictEqual({
			cody: 'Alright, how can I help you?',
			details: 'I want to help you',
			type: CodyResponseType.Question,
			reply: expect.any(Function),
		});
	});

	it('test /ai -unknown command', async () => {
		const repl = '/ai -unknown command';
		const response = await handleCommand(repl);
		expect(response).toStrictEqual({
			cody: 'Unknown or incomplete Command',
			details: 'Try /ai -chat or -m',
			type: CodyResponseType.Question,
			reply: expect.any(Function),
		});
	});

	it('test /exit', async () => {
		const repl = '/exit';
		const response = await handleCommand(repl);
		expect(response).toStrictEqual({
			cody: 'Conversation ended.',
			details: 'I hope I could help',
			type: CodyResponseType.Info,
		});
	});

	it('test /end', async () => {
		const repl = '/exit';
		const response = await handleCommand(repl);
		expect(response).toStrictEqual({
			cody: 'Conversation ended.',
			details: 'I hope I could help',
			type: CodyResponseType.Info,
		});
	});

	it('test unknown command', async () => {
		const repl = '/unknown';
		const response = await handleCommand(repl);
		expect(response).toStrictEqual({
			cody: 'Dont know this command',
			details: ':cody_tears:',
			type: CodyResponseType.Question,
			reply: expect.any(Function),
		});
	});
});

describe('chatMode', () => {
	it('test chat prompt', async () => {
		const response = await chatMode('How are you ?');
		expect(response).toHaveProperty('cody');
		expect([CodyResponseType.Question, CodyResponseType.Error]).toContain(response.type);
		if (response.type === CodyResponseType.Question) {
			expect(response).toHaveProperty('reply', expect.any(Function));
		} else {
			expect(response).toHaveProperty('details');
		}
	});
});

describe('splitMessage', () => {
	it('should split message correctly', () => {
		expect(splitMessage('/ai -m "hello"')).toStrictEqual({ command: '/ai', prompt: 'hello', parameter: '-m' });
		expect(splitMessage('/tip')).toStrictEqual({ command: '/tip', prompt: '', parameter: '' });
		expect(splitMessage('nonsense')).toStrictEqual({ command: '', prompt: '', parameter: '' });
	});
});

describe('getCodyAnswer', () => {
	it('should get cody answer', () => {
		setCodyAnswer('test');
		expect(getCodyAnswer()).toBe('test');
	});
});

describe('setCodyAnswer', () => {
	it('should set cody answer', () => {
		resetCodyAnswer();
		setCodyAnswer('test');
		expect(getCodyAnswer()).toBe('test');
	});
});

describe('resetCodyAnswer', () => {
	it('should reset cody answer', () => {
		setCodyAnswer('test');
		resetCodyAnswer();
		expect(getCodyAnswer()).toBe('');
	});
});
