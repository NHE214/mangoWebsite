export declare class AiError extends Error {
    constructor(message: string);
}
export declare class AiRequestError extends AiError {
    constructor(message: string);
}
export declare class AiCredentialsError extends AiRequestError {
    constructor(message: string);
}
export declare class AiOverloadError extends AiRequestError {
    constructor(message: string);
}
export declare class AiTimeoutError extends AiError {
    constructor(message: string);
}
export declare class AiResponseError extends AiError {
    constructor(message: string);
}
export declare class PromptGenerationError extends AiError {
    constructor(message: string);
}
export declare class GetMetaDataError extends PromptGenerationError {
    constructor(message: string);
}
