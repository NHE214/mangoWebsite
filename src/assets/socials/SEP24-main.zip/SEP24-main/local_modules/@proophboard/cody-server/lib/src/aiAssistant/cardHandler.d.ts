import { GraphPoint, NodeName } from '@proophboard/cody-types';
import { CardsWithoutPositionList, CardsWithPositionList } from './types';
export declare enum CardTypes {
    Event = "event",
    Command = "command",
    Role = "role",
    Aggregate = "aggregate",
    Document = "document",
    Policy = "policy",
    HotSpot = "hotSpot",
    ExternalSystem = "externalSystem",
    UI = "ui",
    Feature = "feature",
    BoundedContext = "boundedContext",
    FreeText = "freeText",
    Edge = "edge",
    Misc = "misc",
    Icon = "icon",
    Image = "image",
    Layer = "layer"
}
/**
 * connects two cards on the board per ID
 * @param sourceElementID
 * @param targetElementID
 */
export declare function connectElementsByID(sourceElementID: string, targetElementID: string): Promise<any>;
export declare function addMetaData(targetElementId: string, metaData: string): Promise<void>;
/**
 * Connects two elements on the board.
 * @param {string} sourceElementId - The content of the source element.
 * @param {string} targetElementId - The content of the target element.
 */
export declare function connectElements(sourceElementId: string, targetElementId: string): Promise<void>;
/**
 * adds an Element at the given position
 * @param position
 * @param elementType
 * @param name
 */
export declare function addElementAtPosition(position: GraphPoint, elementType: string, name: string): Promise<void>;
/**
 *
 * @param sourceElementID
 * @param name
 * @param elementType
 * @param direction
 */
export declare function addCardNextId(sourceElementID: string, name: string, elementType: string, direction?: string): Promise<string>;
/**
 *
 * @param name
 * @param elementType
 * @param offset
 */
export declare function addCardExtended(name: string, elementType: string, offset?: GraphPoint): Promise<string>;
export declare function checkType(elementType: string): string;
/**
 * get the card name by its ID
 * @param cardId
 */
export declare function getNameById(cardId: string): Promise<NodeName>;
export declare function adjustPosition(cards: CardsWithoutPositionList, position: GraphPoint): CardsWithPositionList;
