import { FilterProcessor } from './FilterProcessor';
export interface Filter {
    processWith: (processor: FilterProcessor) => any;
}
