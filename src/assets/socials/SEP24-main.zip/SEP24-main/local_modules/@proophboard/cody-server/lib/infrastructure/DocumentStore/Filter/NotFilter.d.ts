import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';
export declare class NotFilter implements Filter {
    readonly innerFilter: Filter;
    constructor(innerFilter: Filter);
    processWith(processor: FilterProcessor): any;
}
