/* eslint-disable */
export default {
	testEnvironment: 'node',
	displayName: 'cody-server',
	preset: '../../../jest.preset.js',
	silent: true,
	transform: {
		'^.+\\.[tj]s$': ['ts-jest', { tsconfig: '<rootDir>/tsconfig.spec.json' }],
	},
	moduleFileExtensions: ['ts', 'js', 'html'],
	coverageReporters: ['text', 'lcov'],
	testMatch: ['<rootDir>/src/aiAssistant/tests/**/*.(spec|test).ts'],
};
