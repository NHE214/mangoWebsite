import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';
export declare class DocIdFilter implements Filter {
    readonly val: any;
    constructor(val: any);
    processWith(processor: FilterProcessor): any;
}
