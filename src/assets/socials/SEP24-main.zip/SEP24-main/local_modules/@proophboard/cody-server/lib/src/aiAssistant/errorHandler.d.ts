import { CodyResponse } from '@proophboard/cody-types';

export declare class AiError extends Error {
	constructor(message: string);
}

export declare class AiRequestError extends AiError {
	constructor(message: string);
}

export declare class AiTimeoutError extends AiError {
	constructor(message: string);
}

export declare class AiResponseError extends AiError {
	constructor(message: string);
}

export declare class AiResponseParsingError extends AiError {
	constructor(message: string);
}

export declare class PromptGenerationError extends Error {
	constructor(message: string);
}

export declare class NodeParameterError extends Error {
	constructor(message: string);
}

export declare class CodyTypeError extends NodeParameterError {
	constructor(message: string);
}

export declare class RelativeDirectionError extends NodeParameterError {
	constructor(message: string);
}

export declare class HandleCardError extends Error {
	constructor(message: string);
}

export declare class CardPositioningError extends HandleCardError {
	constructor(message: string);
}

export declare class ProophboardAPIError extends HandleCardError {
	constructor(message: string);
}

/**
 * Handles errors thrown during AI or MongoDB operations and returns an appropriate error response.
 * @param {Error} error - The error object to be handled.
 * @returns {Object} An object containing error information suitable for communication with the user interface.
 * @throws {Error} Throws the original error if it doesn't match known error ErrorTypes.
 */
export declare function errorHandler(error: Error): CodyResponse;

/**
 *
 * Handles errors thrown during AI or MongoDB operations and returns an appropriate error response.
 * @param {Error} error - The error object to be handled.
 * @returns {Object} An object containing error information suitable for communication with the user interface.
 * @throws {Error} Throws the original error if it doesn't match known error ErrorTypes.
 */
