import * as dotenv from 'dotenv';

dotenv.config();

export const API_KEY = process.env.API_KEY as string;

export const BOARD_ID = process.env.BOARD_ID as string;
if (!API_KEY) {
	throw new Error('Missing API_KEY in environment variables');
}
