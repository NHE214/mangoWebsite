import { DB } from "./Postgres/DB";
export declare const getConfiguredDB: () => DB;
