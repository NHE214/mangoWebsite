export declare const API_KEY: string;
export declare const BOARD_ID: string;
