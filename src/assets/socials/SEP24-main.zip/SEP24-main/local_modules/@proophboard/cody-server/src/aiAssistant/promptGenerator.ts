import fs from 'fs';
import path from 'path';
import { GetMetaDataError, PromptGenerationError } from './errorHandling/ErrorTypes/AiError';
import {
	Card,
	CardsWithoutPositionList,
	CardsWithPositionList,
	OperationList,
	PromptConfig,
	PromptConfigList,
} from './types';
import { CodyConfig } from '../config/codyconfig';
import { getCodyConfig } from '../http/question';

async function loadPrompts(): Promise<PromptConfigList> {
	const data = await fs.promises.readFile(
		path.join(__dirname, '../../../src/aiAssistant/dialogs/prompts.json'),
		'utf8'
	);
	return JSON.parse(data);
}

async function loadMetaDataTemplates(): Promise<OperationList> {
	const data = await fs.promises.readFile(
		path.join(__dirname, '../../../src/aiAssistant/dialogs/metaDataTemplates.json'),
		'utf8'
	);
	return JSON.parse(data);
}

function replacePlaceholders(promptConfig: PromptConfig, replacements: { [key: string]: string }): PromptConfig {
	const updatedPromptConfig: PromptConfig = { ...promptConfig };
	(Object.keys(promptConfig) as Array<keyof PromptConfig>).forEach((key: keyof PromptConfig) => {
		let value = promptConfig[key];
		Object.entries(replacements).forEach(([placeholder, replacementValue]) => {
			value = value.replace(new RegExp(placeholder, 'g'), replacementValue);
		});
		updatedPromptConfig[key] = value;
	});
	//console.log(JSON.stringify(updatedPromptConfig, null, 2));
	return updatedPromptConfig;
}

async function generatePrompt({
	command,
	systemOperation = '',
	cards = '',
	response = '',
	substitute = '',
}: {
	command: string;
	systemOperation?: string;
	cards?: string;
	response?: string;
	substitute?: string;
}): Promise<PromptConfig> {
	const prompts = await loadPrompts();
	const promptConfig = prompts.commands.find(p => p.command === command);

	if (!promptConfig) {
		throw new PromptGenerationError('Unknown Command in PromptGeneration.');
	}

	//TODO: outsource somehow

	const replacements: { [key: string]: string } = {
		'<<cards>>': cards,
		'<<response>>': response,
		'<<substitute>>': substitute,
		'<<metaData>>': systemOperation ? await getMetaDataTemplate(systemOperation) : '',
	};

	return replacePlaceholders(promptConfig, replacements);
}

async function getCardString(config?: CodyConfig | CardsWithPositionList | CardsWithoutPositionList): Promise<string> {
	let cards: Card[] = [];

	if (!config) {
		config = await getCodyConfig();
		config.context.syncedNodes.forEach(node => {
			let card: Card = {
				name: node.getName(),
				type: node.getType(),
				id: node.getId(),
				geometry: node.getGeometry(),
			};
			cards.push(card);
		});
	} else {
		if ('cards' in config) {
			config.cards.forEach(c => {
				let card: Card = {
					name: c.name,
					type: c.type,
					id: c.name,
					geometry: (c as any).geometry,
				};
				cards.push(card);
			});
		}
	}
	if (!cards || cards.length === 0) {
		throw new PromptGenerationError('Unable to find any cards.');
	}
	let cardString = '';
	cards.forEach(card => {
		cardString += `Card Type: ${card.type}, Card Title: ${card.name}, Card Id: '${card.id}'\n`;
	});
	return cardString;
}

async function getMetaDataTemplate(systemOperation: string) {
	const operationList = await loadMetaDataTemplates();
	const template = operationList.operations.find(p => p.operation === systemOperation);
	if (!template) {
		throw new GetMetaDataError(`Couldn't find ${systemOperation} template`);
	}
	return template.metaDataTemplate;
}

export { generatePrompt, getCardString };
