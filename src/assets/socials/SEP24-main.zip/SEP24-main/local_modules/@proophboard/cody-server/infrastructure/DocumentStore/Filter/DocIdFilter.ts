import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';

export class DocIdFilter implements Filter {
	public readonly val: any;

	constructor(val: any) {
		this.val = val;
	}

	processWith(processor: FilterProcessor): any {
		return processor.processDocIdFilter(this);
	}
}
