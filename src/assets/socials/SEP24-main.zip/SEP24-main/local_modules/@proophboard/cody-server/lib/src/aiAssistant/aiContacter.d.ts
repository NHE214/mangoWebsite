import { Conversation } from './types';
/**
 * Retrieves the ongoing conversation.
 * @returns {any[]} The ongoing conversation.
 */
export declare function getOngoingConversation(): Conversation[];
/**
 * Sets the ongoing conversation.
 * @param {any[]} conversation - The conversation to set.
 */
export declare function setOngoingConversation(conversation: Conversation[]): void;
export declare function timeoutPromise<T>(promise: Promise<T>, timeoutMs: number): Promise<T>;
/**
 * Contacts the AI model API with the provided prompt.
 * @param {string} prompt - The prompt for the AI.
 * @param jsonMode
 * @param timeoutMs - Amount of time in ms, which is waited til a timeout occurs.
 * @returns {Promise<string>} The response from the AI.
 * @throws {AiError} Throws an error if there is an issue with the API request.
 */
export declare function contactAI(prompt: string, jsonMode?: boolean, timeoutMs?: number): Promise<string>;
export declare function parseAiResponse<T>(response: string): T;
