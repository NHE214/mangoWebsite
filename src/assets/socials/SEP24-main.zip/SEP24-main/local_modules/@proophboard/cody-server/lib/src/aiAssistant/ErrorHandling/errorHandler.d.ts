import { CodyResponse } from '@proophboard/cody-types';
/**
 * Handles errors thrown during AI or MongoDB operations and returns an appropriate error response.
 * @param {Error} error - The error object to be handled.
 * @returns {Object} An object containing error information suitable for communication with the user interface.
 * @throws {Error} Throws the original error if it doesn't match known error ErrorTypes.
 */
export declare function errorHandler(error: Error): CodyResponse;
