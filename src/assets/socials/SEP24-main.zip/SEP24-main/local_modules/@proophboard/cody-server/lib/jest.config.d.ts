declare const _default: {
    testEnvironment: string;
    displayName: string;
    preset: string;
    silent: boolean;
    transform: {
        '^.+\\.[tj]s$': (string | {
            tsconfig: string;
        })[];
    };
    moduleFileExtensions: string[];
    coverageReporters: string[];
    testMatch: string[];
};
export default _default;
