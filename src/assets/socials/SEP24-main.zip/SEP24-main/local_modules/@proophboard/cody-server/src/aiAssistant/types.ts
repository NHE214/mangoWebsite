import { GraphPoint } from '@proophboard/cody-types';
import { SystemOperations } from './creationMode';

export type Card = {
	name: string;
	type: string;
	id: string;
	geometry: GraphPoint;
};

export type proophBoardAPIRequest = {
	elementId?: string;
	boardId?: string;
	source?: string;
	target?: string;
	nextToElementId?: string;
	type?: string;
	name?: string;
	content?: string;
	position?: GraphPoint | string;
	parent?: string;
	metadata?: string;
	size?: {
		width: number;
		height: number;
	};
	margin?: number;
	center?: boolean;
};

export type PromptConfig = {
	command: string;
	introduction: string;
	JSONConversion: string;
	explanation: string;
	metaDecision: string;
	entityCreation: string;
	systemDescription: string;
	cardCreation: string;
};
export type PromptConfigList = {
	commands: PromptConfig[];
};

export type CardsWithoutPositionList = {
	cards: CardWithoutPosition[];
};

export type CardsWithPositionList = {
	cards: CardWithPosition[];
};

export type CardWithoutPosition = {
	name: string;
	type: string;
};

export type CardWithPosition = {
	name: string;
	type: string;
	geometry: GraphPoint;
};

export type CardConnections = {
	cards: [
		{
			sourceCardId: 'Card Id';
			targetCardId: 'Card Id';
		}
	];
};

export type Conversation = {
	role: string;
	content: string;
};

export type InputValidation = [validation: 'correct' | 'error'];

export type MetaDataDecision = {
	type: SystemOperations;
};

export type SystemDescription = [
	{
		sentence: string;
	},
	{
		sentence: string;
	},
	{
		sentence: string;
	}
];

export type EntityDecision = {
	name: string;
};

export type Operation = {
	operation: string;
	metaDataTemplate: string;
};

export type OperationList = {
	operations: Operation[];
};
