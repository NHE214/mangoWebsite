import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';
export declare class AndFilter implements Filter {
    readonly internalFilters: Filter[];
    constructor(aFilter: Filter, bFilter: Filter, ...otherFilters: Filter[]);
    processWith(processor: FilterProcessor): any;
}
