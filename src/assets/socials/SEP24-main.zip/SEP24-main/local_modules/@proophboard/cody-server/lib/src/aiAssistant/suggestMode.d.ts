import { CodyResponseType } from '@proophboard/cody-types';
/**
 * Activates suggest mode and recommends new cards, based on the card provided.
 * @param {any} config - The configuration object.
 * @param {any[]} nodes - The cards to consider.
 * @returns {Promise<{ cody: string; type: CodyResponseType }>} An object containing the Cody response.
 */
export declare function activateSuggestMode(config: any, nodes: any[]): Promise<{
    cody: string;
    type: CodyResponseType;
}>;
