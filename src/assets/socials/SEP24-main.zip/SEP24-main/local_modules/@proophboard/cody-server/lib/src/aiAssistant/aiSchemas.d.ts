/**
 * Interface representing a scheme for contacting an AI model.
 */
export interface Scheme {
    authorization: string;
    messagePath?: string;
    jsonScheme: any;
    url: string;
    scheme: any;
}
/**
 * Scheme configuration for contacting the GPT AI model.
 */
export declare let gptScheme: Scheme;
/**
 * Scheme configuration for contacting the Llama AI model.
 */
export declare let codestralScheme: Scheme;
