import {
	AiCredentialsError,
	AiOverloadError,
	AiRequestError,
	AiResponseError,
	AiTimeoutError,
} from './errorHandling/ErrorTypes/AiError';
import { AiResponseParsingError } from './errorHandling/ErrorTypes/AiResponseParsingError';
import { gptScheme } from './aiSchemas';
import { Conversation } from './types';

const jp = require('jsonpath');
let ongoingConversation: Conversation[] = [];
let currentAIScheme = gptScheme;

/**
 * Retrieves the ongoing conversation.
 * @returns {any[]} The ongoing conversation.
 */
export function getOngoingConversation(): Conversation[] {
	return ongoingConversation;
}

/**
 * Sets the ongoing conversation.
 * @param {any[]} conversation - The conversation to set.
 */
export function setOngoingConversation(conversation: Conversation[]): void {
	ongoingConversation = conversation;
}

export async function timeoutPromise<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
	let timeout: NodeJS.Timeout;

	const timeoutPromise = new Promise<T>((_resolve, reject) => {
		timeout = setTimeout(() => {
			reject(new AiTimeoutError(`${timeoutMs}`));
		}, timeoutMs);
	});
	return Promise.race([promise, timeoutPromise]).then(result => {
		clearTimeout(timeout);
		if (result instanceof AiTimeoutError) {
			contactAI('Stop processing the request you are processing.');
		}
		return result;
	});
}

/**
 * Contacts the AI model API with the provided prompt.
 * @param {string} prompt - The prompt for the AI.
 * @param jsonMode
 * @param timeoutMs - Amount of time in ms, which is waited til a timeout occurs.
 * @returns {Promise<string>} The response from the AI.
 * @throws {AiError} Throws an error if there is an issue with the API request.
 */
export async function contactAI(prompt: string, jsonMode: boolean = false, timeoutMs: number = 50000): Promise<string> {
	const authorisation: string = currentAIScheme.authorization;
	ongoingConversation.push({
		role: 'user',
		content: prompt,
	});

	//console.log(ongoingConversation);

	let requestData = currentAIScheme.scheme;
	if (jsonMode) {
		requestData = currentAIScheme.jsonScheme;
	}
	requestData.messages = ongoingConversation;

	const start = process.hrtime.bigint();

	let response;
	try {
		response = await timeoutPromise(
			fetch(currentAIScheme.url, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					Authorization: `Bearer ${authorisation}`,
				},
				body: JSON.stringify(requestData),
			}),
			timeoutMs
		);
	} catch (TypeError) {
		throw new AiRequestError('fetch failed');
	}

	if (!response.ok) {
		console.log('Response status: ' + response.status);
		if (response.status === 401) {
			throw new AiCredentialsError(`${response.statusText}`);
		} else if (response.status === 429) {
			throw new AiOverloadError(`${response.statusText}`);
		}
		throw new AiResponseError(`${response.statusText}`);
	}

	const end = process.hrtime.bigint();
	const time = end - start;
	let responseData = await response.json();
	// necessary to ensure clean JSON object
	responseData = JSON.parse(JSON.stringify(responseData));
	const apiResponse = jp.value(responseData, currentAIScheme.messagePath);
	//console.log(apiResponse);
	/*console.log(`
----------------------------------------------------------------------------------------------------------------------------------------
	time: ${time}
----------------------------------------------------------------------------------------------------------------------------------------
	`);*/

	ongoingConversation.push({
		role: 'system',
		content: apiResponse,
	});

	return apiResponse;
}

export function parseAiResponse<T>(response: string): T {
	try {
		return JSON.parse(response);
	} catch (error) {
		throw new AiResponseParsingError(`${error}`);
	}
}
