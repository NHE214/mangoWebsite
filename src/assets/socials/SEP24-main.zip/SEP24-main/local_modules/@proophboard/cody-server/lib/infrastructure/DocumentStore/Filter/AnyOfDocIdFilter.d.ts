import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';
export declare class AnyOfDocIdFilter implements Filter {
    readonly valList: any[];
    constructor(valList: any[]);
    processWith(processor: FilterProcessor): any;
}
