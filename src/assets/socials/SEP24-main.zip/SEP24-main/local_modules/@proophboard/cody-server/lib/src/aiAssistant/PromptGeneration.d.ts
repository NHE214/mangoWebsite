interface PromptConfig {
    command: string;
    introduction: string;
    JSONConversion: string;
    explanation: string;
}
declare function readFile(filePath: string): Promise<string>;
declare function generatePrompt({ command, cards, response, message, substitute, }: {
    command: string;
    cards?: string;
    response?: string;
    message?: string;
    substitute?: string;
}): Promise<PromptConfig>;
declare function getCardString(): Promise<string>;
export { readFile, generatePrompt, getCardString };
