export class SyncError extends Error {
	constructor(message: string) {
		super(message);
		this.name = 'SyncError';
		Error.captureStackTrace(this, SyncError);
	}
}

export class MissingBoardIdError extends SyncError {
	constructor(message: string) {
		super(message);
		this.name = 'MissingBoardIdError';
		Error.captureStackTrace(this, MissingBoardIdError);
	}
}
