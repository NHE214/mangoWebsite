export declare const PERSISTENT_COLLECTION_FILE: string;
export declare const getConfiguredDocumentStore: () => any;
