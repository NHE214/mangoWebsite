export declare class SyncError extends Error {
    constructor(message: string);
}
export declare class MissingBoardIdError extends SyncError {
    constructor(message: string);
}
