import { AiError } from './AiError';
export declare class AiResponseParsingError extends AiError {
    constructor(message: string);
}
