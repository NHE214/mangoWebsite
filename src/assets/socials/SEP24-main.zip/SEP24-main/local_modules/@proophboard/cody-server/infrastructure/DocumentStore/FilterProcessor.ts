import { EqFilter } from './Filter/EqFilter';
import { AnyFilter } from './Filter/AnyFilter';
import { AndFilter } from './Filter/AndFilter';
import { Filter } from './Filter';
import { OrFilter } from './Filter/OrFilter';
import { DocIdFilter } from './Filter/DocIdFilter';
import { ExistsFilter } from './Filter/ExistsFilter';
import { GtFilter } from './Filter/GtFilter';
import { GteFilter } from './Filter/GteFilter';
import { LteFilter } from './Filter/LteFilter';
import { InArrayFilter } from './Filter/InArrayFilter';
import { LikeFilter } from './Filter/LikeFilter';
import { NotFilter } from './Filter/NotFilter';
import { AnyOfDocIdFilter } from './Filter/AnyOfDocIdFilter';
import { AnyOfFilter } from './Filter/AnyOfFilter';
import { LtFilter } from './Filter/LtFilter';

export interface FilterProcessor {
	process: (filter: Filter) => any;
	processAnyFilter: (filter: AnyFilter) => any;
	processEqFilter: (filter: EqFilter) => any;
	processAndFilter: (filter: AndFilter) => any;
	processOrFilter: (filter: OrFilter) => any;
	processDocIdFilter: (filter: DocIdFilter) => any;
	processExistsFilter: (filter: ExistsFilter) => any;
	processGtFilter: (filter: GtFilter) => any;
	processGteFilter: (filter: GteFilter) => any;
	processLtFilter: (filter: LtFilter) => any;
	processLteFilter: (filter: LteFilter) => any;
	processInArrayFilter: (filter: InArrayFilter) => any;
	processLikeFilter: (filter: LikeFilter) => any;
	processNotFilter: (filter: NotFilter) => any;
	processAnyOfDocIdFilter: (filter: AnyOfDocIdFilter) => any;
	processAnyOfFilter: (filter: AnyOfFilter) => any;
}
