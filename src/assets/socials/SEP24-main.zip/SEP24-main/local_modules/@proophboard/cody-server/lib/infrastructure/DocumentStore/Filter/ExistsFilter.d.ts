import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';
export declare class ExistsFilter implements Filter {
    readonly prop: string;
    constructor(prop: string);
    processWith(processor: FilterProcessor): any;
}
