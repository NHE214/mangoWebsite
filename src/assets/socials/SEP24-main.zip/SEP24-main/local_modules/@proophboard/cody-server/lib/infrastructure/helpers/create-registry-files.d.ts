declare const path: any, fs: any;
/**
 * Iterates recursively over a directory and calls the callback function on any file that matches the given regex pattern.
 */
declare function fromDir(startPath: string, filter: RegExp, callback: (pathName: string) => void): void;
declare const packagesPath: any;
declare const regex: RegExp;
