import { FilterProcessor } from '../FilterProcessor';
import { Filter } from '../Filter';
import { AnyFilter } from '../Filter/AnyFilter';
import { EqFilter } from '../Filter/EqFilter';
import { getValueFromPath } from '../helpers';
import { AndFilter } from '../Filter/AndFilter';
import { OrFilter } from '../Filter/OrFilter';
import { DocIdFilter } from '../Filter/DocIdFilter';
import { ExistsFilter } from '../Filter/ExistsFilter';
import { GtFilter } from '../Filter/GtFilter';
import { GteFilter } from '../Filter/GteFilter';
import { LtFilter } from '../Filter/LtFilter';
import { LteFilter } from '../Filter/LteFilter';
import { InArrayFilter } from '../Filter/InArrayFilter';
import { LikeFilter } from '../Filter/LikeFilter';
import { NotFilter } from '../Filter/NotFilter';
import { AnyOfDocIdFilter } from '../Filter/AnyOfDocIdFilter';
import { AnyOfFilter } from '../Filter/AnyOfFilter';

type ReturnType = (doc: any, docId: string) => boolean;

export class InMemoryFilterProcessor implements FilterProcessor {
	process(filter: Filter): ReturnType {
		return filter.processWith(this);
	}

	processAnyFilter(filter: AnyFilter): ReturnType {
		return () => true;
	}

	processEqFilter(filter: EqFilter): ReturnType {
		return (doc: any) => getValueFromPath(filter.prop, doc) === filter.val;
	}

	processAndFilter(filter: AndFilter): ReturnType {
		return (doc: any, docId: string) => {
			const filterFunctions = filter.internalFilters.map(innerFilter => innerFilter.processWith(this));
			return filterFunctions.every(filterFunction => filterFunction(doc, docId));
		};
	}

	processOrFilter(filter: OrFilter): ReturnType {
		return (doc: any, docId: string) => {
			const filterFunctions = filter.internalFilters.map(innerFilter => innerFilter.processWith(this));
			return filterFunctions.some(filterFunction => filterFunction(doc, docId));
		};
	}

	processDocIdFilter(filter: DocIdFilter): ReturnType {
		return (doc: any, docId: string) => docId === filter.val;
	}

	processExistsFilter(filter: ExistsFilter): ReturnType {
		return (doc: any) => getValueFromPath(filter.prop, doc) !== undefined;
	}

	processGtFilter(filter: GtFilter): ReturnType {
		return (doc: any) => getValueFromPath(filter.prop, doc) > filter.val;
	}

	processGteFilter(filter: GteFilter): ReturnType {
		return (doc: any) => getValueFromPath(filter.prop, doc) >= filter.val;
	}

	processLtFilter(filter: LtFilter): ReturnType {
		return (doc: any) => getValueFromPath(filter.prop, doc) < filter.val;
	}

	processLteFilter(filter: LteFilter): ReturnType {
		return (doc: any) => getValueFromPath(filter.prop, doc) <= filter.val;
	}

	processInArrayFilter(filter: InArrayFilter): ReturnType {
		return (doc: any) => {
			const value = getValueFromPath(filter.prop, doc);
			return Array.isArray(value) && value.includes(filter.val);
		};
	}

	processLikeFilter(filter: LikeFilter): ReturnType {
		return (doc: any) => {
			const value = getValueFromPath(filter.prop, doc);

			if (typeof value !== 'string') {
				return false;
			}

			const start = filter.prop.startsWith('%') && value.endsWith(filter.prop.slice(1));
			const end = filter.prop.endsWith('%') && value.startsWith(filter.prop.slice(0, -1));
			return start && end;
		};
	}

	processNotFilter(filter: NotFilter): ReturnType {
		return (doc: any, docId: string) => {
			const filterFunction = filter.innerFilter.processWith(this);
			return !filterFunction(doc, docId);
		};
	}

	processAnyOfDocIdFilter(filter: AnyOfDocIdFilter): ReturnType {
		return (doc: any, docId: string) => filter.valList.includes(docId);
	}

	processAnyOfFilter(filter: AnyOfFilter): ReturnType {
		return (doc: any) => {
			const value = getValueFromPath(filter.prop, doc);
			return filter.valList.includes(value);
		};
	}
}
