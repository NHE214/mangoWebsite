import { getCodyConfig } from '../http/question';
import { CodyResponseType, GraphPoint } from '@proophboard/cody-types';
import { generatePrompt, getCardString } from './promptGenerator';
import { Commands, handleCommand } from './commandHandler';
import { addElementAtPosition, addMetaData, adjustPosition, CardTypes, connectElements } from './cardHandler';
import { CardConnections, CardsWithoutPositionList } from './types';
import { contactAI, parseAiResponse, setOngoingConversation } from './aiInteraction';
import { buyingTime, SystemOperations } from './creationMode';
import { deleteAllConversations } from './databaseInteraction';

/**
 * gets called upon after using the /tip function, sends the tips to the AI and lets it generate a JSON formated answer
 * which is prompted and used to implement the cards on the board using the addElementAtPosition function.
 * @param command
 * @param text
 * @param cardType
 */
export async function generateCardsFromText(command: string, text: string, cardType?: CardTypes): Promise<any> {
	const prompt = await generatePrompt({ command: command, response: text, cards: await getCardString() });
	let responseTipToJSON = await contactAI(prompt.JSONConversion, true);

	const tipJSON = parseAiResponse<CardsWithoutPositionList>(responseTipToJSON);
	let position: GraphPoint = { x: 0, y: 0 };
	let counter: number = 0;

	if (cardType) {
		for (const card of tipJSON.cards) {
			position = { x: (counter % 10) * 200, y: Math.floor(counter / 10) * 150 };
			await addElementAtPosition(position, cardType, card.name);
			counter++;
		}
	} else {
		for (const card of tipJSON.cards) {
			position = { x: (counter % 10) * 200, y: Math.floor(counter / 10) * 150 };
			await addElementAtPosition(position, card.type, card.name);
			counter++;
		}
	}
	return {
		cody: 'Stickies have been put on the board',
		type: CodyResponseType.Question,
		reply: async (userReply: string) => {
			return handleCommand(userReply);
		},
	};
}

/**
 * gets called upon after using the /flows function, sends the flows response to the AI and lets it generate a JSON formated answer
 * which is prompted and used to implement the connections on the board using the connectElements function.
 * @param text
 */
export async function generateCardConnectionsFromText(text: string): Promise<any> {
	let prompt = await generatePrompt({ command: Commands.flows, response: text, cards: await getCardString() });
	let responseFlowsToJSON: string = await contactAI(prompt.JSONConversion, true);
	const flowsJSON = parseAiResponse<CardConnections>(responseFlowsToJSON);

	for (const card of flowsJSON.cards) {
		await connectElements(card.sourceCardId, card.targetCardId);
		await buyingTime(500);
	}

	return {
		cody: 'Stickies have been connected',
		type: CodyResponseType.Question,
		reply: async (userReply: string) => {
			return handleCommand(userReply);
		},
	};
}

export async function generateSuggestion(eventName: string) {
	let config = await getCodyConfig();
	let position: GraphPoint = { x: 0, y: 300 };
	let substitute: string = ' one event Type Card with the name ' + eventName + ',';
	config.context.syncedNodes.forEach(node => {
		if (node.getName().toLowerCase() === eventName.toLowerCase()) {
			position = node.getGeometry();
			substitute = '';
		}
	});

	let prompt = await generatePrompt({ command: Commands.suggest, response: eventName, substitute: substitute });

	let suggestResponse: string = await contactAI(prompt.introduction);
	let suggestResponseWithPositions = adjustPosition(
		parseAiResponse<CardsWithoutPositionList>(suggestResponse),
		position
	);
	for (const card of suggestResponseWithPositions.cards) {
		await addElementAtPosition(card.geometry, card.type, card.name);
	}

	prompt = await generatePrompt({
		command: Commands.suggest,
		cards: await getCardString(suggestResponseWithPositions),
	});

	return contactAI(prompt.explanation);
}

/**
 * @param title
 * @param elementId
 * @param systemOperation
 */
export async function generateMetaData(title: string, elementId: string, systemOperation: SystemOperations) {
	let config = await getCodyConfig();
	await deleteAllConversations();
	setOngoingConversation([]);
	let targetElementId: string = '';
	let targetElementType: string = '';
	let targetElementName: string = '';
	config.context.syncedNodes.forEach(node => {
		if (node.getId() === elementId) {
			targetElementId = node.getId();
			targetElementType = node.getType();
			targetElementName = node.getName();
		}
	});
	const prompt = await generatePrompt({
		command: Commands.metaData,
		cards: '\ntitle: ' + title + ' , name: ' + targetElementName + ' , type: ' + targetElementType,
		systemOperation: systemOperation,
	});
	const response = await contactAI(prompt.JSONConversion);
	await addMetaData(targetElementId, response);
}
