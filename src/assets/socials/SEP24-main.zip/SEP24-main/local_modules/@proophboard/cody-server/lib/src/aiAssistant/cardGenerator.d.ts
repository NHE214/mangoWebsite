import { CardTypes } from './cardHandler';
import { SystemOperations } from './creationMode';
/**
 * gets called upon after using the /tip function, sends the tips to the AI and lets it generate a JSON formated answer
 * which is prompted and used to implement the cards on the board using the addElementAtPosition function.
 * @param command
 * @param text
 * @param cardType
 */
export declare function generateCardsFromText(command: string, text: string, cardType?: CardTypes): Promise<any>;
/**
 * gets called upon after using the /flows function, sends the flows response to the AI and lets it generate a JSON formated answer
 * which is prompted and used to implement the connections on the board using the connectElements function.
 * @param text
 */
export declare function generateCardConnectionsFromText(text: string): Promise<any>;
export declare function generateSuggestion(eventName: string): Promise<string>;
/**
 * @param title
 * @param elementId
 * @param systemOperation
 */
export declare function generateMetaData(title: string, elementId: string, systemOperation: SystemOperations): Promise<void>;
