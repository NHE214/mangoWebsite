import { DocumentStore, PartialSelect, SortOrder } from '../DocumentStore';
import { Index } from './Index';
import { Filter } from './Filter';
import { Filesystem } from '../helpers/fs';
export declare type Documents = {
    [collectionName: string]: {
        [docId: string]: {
            doc: object;
            version: number;
        };
    };
};
export declare class InMemoryDocumentStore implements DocumentStore {
    private documents;
    private persistOnDisk;
    private readonly storageFile;
    private readonly filterProcessor;
    private readonly fs;
    constructor(storageFile?: string, fs?: Filesystem);
    addCollection(collectionName: string, index?: Index): Promise<void>;
    hasCollection(collectionName: string): Promise<boolean>;
    dropCollection(collectionName: string): Promise<void>;
    addCollectionIndex(collectionName: string, index: Index): Promise<void>;
    hasCollectionIndex(collectionName: string, index: Index): Promise<boolean>;
    dropCollectionIndex(collectionName: string, index: Index): Promise<void>;
    addDoc(collectionName: string, docId: string, doc: object, metadata?: object, version?: number): Promise<void>;
    updateDoc(collectionName: string, docId: string, docOrSubset: object, metadata?: object, version?: number): Promise<void>;
    upsertDoc(collectionName: string, docId: string, doc: object, metadata?: object, version?: number): Promise<void>;
    replaceDoc(collectionName: string, docId: string, doc: object, metadata?: object, version?: number): Promise<void>;
    getDoc<D extends object>(collectionName: string, docId: string): Promise<D | null>;
    getPartialDoc<D extends object>(collectionName: string, docId: string, partialSelect: PartialSelect): Promise<D | null>;
    getDocAndVersion<D extends object>(collectionName: string, docId: string): Promise<{
        doc: D;
        version: number;
    } | null>;
    getDocVersion<D extends object>(collectionName: string, docId: string): Promise<number | null>;
    deleteDoc(collectionName: string, docId: string): Promise<void>;
    updateMany(collectionName: string, filter: Filter, set: object, metadata?: object, version?: number): Promise<void>;
    replaceMany(collectionName: string, filter: Filter, set: object, metadata?: object, version?: number): Promise<void>;
    deleteMany(collectionName: string, filter: Filter): Promise<void>;
    findDocs<D extends object>(collectionName: string, filter: Filter, skip?: number, limit?: number, orderBy?: SortOrder): Promise<AsyncIterable<[string, D, number]>>;
    findPartialDocs<D extends object>(collectionName: string, partialSelect: PartialSelect, filter: Filter, skip?: number, limit?: number, orderBy?: SortOrder): Promise<AsyncIterable<[string, D, number]>>;
    findDocIds(collectionName: string, filter: Filter, skip?: number, limit?: number, orderBy?: SortOrder): Promise<string[]>;
    countDocs(collectionName: string, filter: Filter): Promise<number>;
    disableDiskStorage(): void;
    enableDiskStorage(): void;
    flush(): void;
    importDocuments(documents: Documents): Promise<void>;
    exportDocuments(): Promise<Documents>;
    syncExportDocuments(): Documents;
    private migrateDocs;
    private persistOnDiskIfEnabled;
    private assertHasCollection;
}
