import { CardsWithoutPositionList, CardsWithPositionList, PromptConfig } from './types';
import { CodyConfig } from '../config/codyconfig';
declare function generatePrompt({ command, systemOperation, cards, response, substitute, }: {
    command: string;
    systemOperation?: string;
    cards?: string;
    response?: string;
    substitute?: string;
}): Promise<PromptConfig>;
declare function getCardString(config?: CodyConfig | CardsWithPositionList | CardsWithoutPositionList): Promise<string>;
export { generatePrompt, getCardString };
