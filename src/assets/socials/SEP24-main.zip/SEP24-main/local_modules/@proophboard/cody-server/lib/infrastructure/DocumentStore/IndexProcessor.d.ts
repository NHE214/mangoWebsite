import { FieldIndex } from './Index/FieldIndex';
import { Index } from './Index';
import { MultiFieldIndex } from './Index/MultiFieldIndex';
import { MetadataFieldIndex } from './Index/MetadataFieldIndex';
export interface IndexProcessor {
    process: (index: Index, tableName: string) => any;
    processFieldIndex: (index: FieldIndex, tableName: string) => any;
    processMultiFieldIndex: (index: MultiFieldIndex, tableName: string) => any;
    processMetadataFieldIndex: (index: MetadataFieldIndex, tableName: string) => any;
}
