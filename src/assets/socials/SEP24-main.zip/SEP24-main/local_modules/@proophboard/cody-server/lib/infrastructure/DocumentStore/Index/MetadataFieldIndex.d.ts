import { Index } from '../Index';
import { Sort } from '../../DocumentStore';
import { IndexProcessor } from '../IndexProcessor';
export declare class MetadataFieldIndex implements Index {
    readonly name: string;
    readonly field: string;
    readonly unique?: boolean;
    readonly sort?: Sort;
    static forField(name: string, field: string, sort?: Sort, unique?: boolean): MetadataFieldIndex;
    private constructor();
    processWith(indexProcessor: IndexProcessor, tableName: string): any;
}
