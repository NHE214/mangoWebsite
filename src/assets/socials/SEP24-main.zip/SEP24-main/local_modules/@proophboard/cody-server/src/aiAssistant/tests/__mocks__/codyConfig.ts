import { Node, NodeTag, NodeType } from '@proophboard/cody-types';
import { List, Map } from 'immutable';
import { CodyConfig } from '../../../config/codyconfig';

const mockNode: Node = {
	getId: () => 'mockNodeId',
	getName: () => 'Mock Node',
	getDescription: () => '',
	getType: () => NodeType.event,
	getLink: () => '',
	getTags: () => List<NodeTag>(),
	isLayer: () => false,
	isDefaultLayer: () => false,
	getParent: () => null,
	getChildren: () => List<Node>(),
	getSources: () => List<Node>(),
	getTargets: () => List<Node>(),
	getGeometry: () => ({ x: 0, y: 0 }),
	getMetadata: () => null,
	withChildren: childrenList => mockNode,
	withSources: sourcesList => mockNode,
	withTargets: targetsList => mockNode,
};

export const mockedCodyConfig: CodyConfig = {
	context: {
		syncedNodes: Map<string, Node>().set('hallo', mockNode),
		boardId: 'mockBoardId',
		boardName: 'Mock Board',
		userId: 'mockUserId',
	},
	hooks: {},
};
