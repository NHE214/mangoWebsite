import { Pool, QueryResult } from 'pg';
export declare enum IsolationLevel {
    readUncommitted = "READ UNCOMMITTED",
    readCommitted = "READ COMMITTED",
    repeatableRead = "REPEATABLE READ",
    serializable = "SERIALIZABLE"
}
export declare class DB {
    private readonly pool;
    constructor(pool: Pool);
    query(query: string, values?: any[]): Promise<QueryResult>;
    iterableCursor<T>(query: string, values?: any[]): Promise<AsyncIterable<T>>;
    transaction(queryGenerator: any, isolationLevel?: IsolationLevel): Promise<void>;
}
