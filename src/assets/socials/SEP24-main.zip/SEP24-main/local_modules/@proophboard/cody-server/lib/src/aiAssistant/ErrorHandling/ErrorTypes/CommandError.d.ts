export declare class CommandError extends Error {
    constructor(message: string);
}
export declare class CommandNotFoundError extends CommandError {
    constructor(message: string);
}
