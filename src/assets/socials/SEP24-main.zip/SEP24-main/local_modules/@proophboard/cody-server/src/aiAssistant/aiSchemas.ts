/**
 * Interface representing a scheme for contacting an AI model.
 */

export interface Scheme {
	authorization: string;
	messagePath?: string;
	jsonScheme: any;
	url: string;
	scheme: any;
}

/**
 * Scheme configuration for contacting the GPT AI model.
 */
export let gptScheme: Scheme = {
	authorization: 'sk-proj-Yq1H5youCtfxDTWi9RL4T3BlbkFJ445460o3xUUO6WwUyyqj',
	url: 'https://api.openai.com/v1/chat/completions',
	scheme: {
		model: 'gpt-3.5-turbo',
		messages: [{ role: 'user', content: '' }],
		stream: false,
	},
	jsonScheme: {
		model: 'gpt-3.5-turbo',
		messages: [{ role: 'user', content: '' }],
		response_format: {
			type: 'json_object',
		},
		stream: false,
	},
	messagePath: '$.choices[0].message.content',
};
/**
 * Scheme configuration for contacting the Llama AI model.
 */
export let codestralScheme: Scheme = {
	authorization: 'SuTkU/W2QnmuK9YcflVQf+hOikGeVw5cDYnFGjku/pYy7E0xQmZS8Q3saoNrfv/T',
	url: 'https://f4359ba8-80fc-455d-a8e6-fad069f30239.app.gra.ai.cloud.ovh.net/api/chat',
	scheme: {
		model: 'codestral',
		messages: [{ role: 'user', content: '' }],
		stream: false,
	},
	jsonScheme: {
		model: 'codestral',
		messages: [{ role: 'user', content: '' }],
		format: 'json',
		response_format: { type: 'json_object' },
		stream: false,
	},
	messagePath: '$.message.content',
};
