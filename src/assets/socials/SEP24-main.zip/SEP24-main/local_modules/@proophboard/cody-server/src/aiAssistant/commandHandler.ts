import { CodyResponse, CodyResponseType } from '@proophboard/cody-types';
import {
	deleteAllConversations,
	getConversationHistory,
	loadConversationHistory,
	saveConversationToDB,
	testDBAvailability,
} from './databaseInteraction';
import { contactAI, setOngoingConversation } from './aiInteraction';
import { errorHandler } from './errorHandling/errorHandler';
import { getCodyConfig } from '../http/question';
import { eventsCreate, eventsMultiCreate, systemCreate } from './creationMode';
import { generatePrompt, getCardString } from './promptGenerator';
import { generateCardConnectionsFromText, generateCardsFromText, generateSuggestion } from './cardGenerator';
import { CardTypes } from './cardHandler';

let codyAnswer: string = '';

export enum Commands {
	test = '/test',
	exit = '/exit',
	end = '/end',
	ai = '/ai',
	suggest = '/suggest',
	tip = '/tip',
	hotSpots = '/hotSpots',
	flows = '/flows',
	events = '/events',
	history = '/history',
	delete = '/delete',
	create = '/create',
	createPlus = '/createPlus',
	multiCreate = '/multiCreate',
	sync = '/sync',
	metaData = '/metaData',
}

/**
 * Handles user commands.
 * @param {string} repl - The user's input.
 * @returns {Promise<CodyResponse>} The Cody-Response, depending on the command sent.
 */
export async function handleCommand(repl: string): Promise<CodyResponse> {
	let config = await getCodyConfig();
	console.log('Replied with: ', repl);
	const message = splitMessage(repl);
	console.log('Command:', message.command);
	console.log('Parameter:', message.parameter);
	try {
		switch (message.command) {
			case Commands.test:
				console.log('Using posgresDB');
				await testDBAvailability();
				return {
					cody: 'test',
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						return handleCommand(userReply);
					},
				};
			case Commands.exit:
			case Commands.end:
				await testDBAvailability();
				await saveConversationToDB();
				setOngoingConversation([]);
				return {
					cody: 'Conversation ended.',
					details: 'I hope I could help',
					type: CodyResponseType.Info,
				};
			case Commands.ai:
				if (message.parameter === '-m') {
					let response = await contactAI(message.prompt);
					return {
						cody: response,
						type: CodyResponseType.Question,
						reply: async (userReply: string) => {
							return handleCommand(userReply);
						},
					};
				} else if (message.parameter === '-chat') {
					return {
						cody: 'Alright, how can I help you?',
						details: 'I want to help you',
						type: CodyResponseType.Question,
						reply: async (userReply: string) => {
							return chatMode(userReply);
						},
					};
				} else {
					return {
						cody: 'Unknown or incomplete Command',
						details: 'Try /ai -chat or -m',
						type: CodyResponseType.Question,
						reply: async (userReply: string) => {
							return handleCommand(userReply);
						},
					};
				}
			case Commands.suggest:
				return {
					cody: 'Write the name of an already existing event card or a new event',
					details:
						'suggested cards will be aligned based on the event card or will start from the center of the board',
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						let suggestResponse: string = await generateSuggestion(userReply);
						return {
							cody: suggestResponse,
							details: 'I hope I could help you',
							type: CodyResponseType.Question,
							reply: async (userReply: string) => {
								return handleCommand(userReply);
							},
						};
					},
				};
			case Commands.tip:
			case Commands.hotSpots:
			case Commands.flows:
				let prompt = await generatePrompt({ command: message.command, cards: await getCardString() });
				let response = await contactAI(prompt.introduction);
				return {
					cody: response + '\n Would you like to add this to your board?',
					details: 'Yes or No',
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						if (userReply.toLowerCase().trim() === 'yes') {
							if (message.command === Commands.flows) {
								return await generateCardConnectionsFromText(response);
							} else if (message.command === Commands.tip) {
								return await generateCardsFromText(message.command, response);
							} else if (message.command === Commands.hotSpots) {
								return await generateCardsFromText(message.command, response, CardTypes.HotSpot);
							}
						} else {
							return {
								cody: 'okay, maybe next time',
								type: CodyResponseType.Question,
								reply: async (userReply: string) => {
									return handleCommand(userReply);
								},
							};
						}
					},
				};
			case Commands.events:
				return {
					cody: 'Enter a short explanation of the System you want events to be created for: ',
					details: 'event cards will start from the center of the board',
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						await generateCardsFromText(message.command, userReply, CardTypes.Event);
						return {
							cody: 'Events based on you request have been put on the Board',
							type: CodyResponseType.Question,
							reply: async (userReply: string) => {
								return handleCommand(userReply);
							},
						};
					},
				};
			case Commands.history:
				await testDBAvailability();
				const history = await getConversationHistory();
				return {
					cody: history,
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						const numberRegex = /^-?\d*.?\d+$/;
						if (numberRegex.test(userReply)) {
							const number = parseFloat(userReply);
							return loadConversationHistory(number);
						}
						return handleCommand(userReply);
					},
				};
			case Commands.delete:
				await deleteAllConversations();
				return {
					cody: 'Histories deleted.',
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						return handleCommand(userReply);
					},
				};
			case Commands.create:
				resetCodyAnswer();
				return {
					cody: 'Enter a short explanation of the System you want to create, like: I want to add shoes to a list.',
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						if (userReply === '/end') {
							return handleCommand(userReply);
						} else {
							await systemCreate(userReply);
							setCodyAnswer('Process finished. Handing back control to cody+');
							return {
								cody: codyAnswer,
								type: CodyResponseType.Question,
								reply: async (userReply: string) => {
									return handleCommand(userReply);
								},
							};
						}
					},
				};
			case Commands.createPlus:
				resetCodyAnswer();
				return {
					cody: 'Enter what you want to maintain, like a customer, employee, book or whatever you like:',
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						if (userReply === '/end') {
							return handleCommand(userReply);
						} else {
							await eventsCreate(userReply);
							setCodyAnswer('Process finished. Handing back control to cody+');
							return {
								cody: codyAnswer,
								type: CodyResponseType.Question,
								reply: async (userReply: string) => {
									return handleCommand(userReply);
								},
							};
						}
					},
				};
			case Commands.multiCreate:
				resetCodyAnswer();
				return {
					cody: 'Enter what kind of system you want to create, like an app or store:',
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						if (userReply === '/end') {
							return handleCommand(userReply);
						} else {
							await eventsMultiCreate(userReply);
							setCodyAnswer('Process finished. Handing back control to cody+');
							return {
								cody: codyAnswer,
								type: CodyResponseType.Question,
								reply: async (userReply: string) => {
									return handleCommand(userReply);
								},
							};
						}
					},
				};
			case Commands.sync:
				console.log('Synchronizing Elements...');
				await syncNodes();
				return await printSynchronizedNodesToConsole();
			default:
				return {
					cody: 'Dont know this command',
					details: ':cody_tears:',
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						return handleCommand(userReply);
					},
				};
		}
	} catch (error: any) {
		console.error(error);
		return errorHandler(error);
	}
}

/**-
 * Function to handle chat mode.
 * @param {string} prompt - The prompt for the chat mode.
 * @returns {Promise<any>} A promise resolving to the response.
 */
export async function chatMode(prompt: string): Promise<any> {
	try {
		switch (prompt) {
			case Commands.exit:
			case Commands.end:
				await testDBAvailability();
				await saveConversationToDB();
				setOngoingConversation([]);
				return {
					cody: 'Conversation ended.',
					details: 'I hope I could help',
					type: CodyResponseType.Info,
				};
			default:
				let response = await contactAI(prompt);
				return {
					cody: response,
					type: CodyResponseType.Question,
					reply: async (userReply: string) => {
						return chatMode(userReply);
					},
				};
		}
	} catch (error: any) {
		console.error(error);
		return errorHandler(error);
	}
}

/**
 * prints alls cards contained in syncedNodes
 */
export async function printSynchronizedNodesToConsole() {
	let cards: any[] = [];
	let config = await getCodyConfig();
	config.context.syncedNodes.forEach(node => {
		let card = {
			name: node.getName(),
			type: node.getType(),
			id: node.getId(),
			metadata: node.getMetadata(),
			parent: JSON.stringify(node.getParent()),
		};
		cards.push(card);
	});
	console.log(cards);
	return {
		cody: 'Synchronizing Nodes.',
		type: CodyResponseType.Question,
		reply: async (userReply: string) => {
			return handleCommand(userReply);
		},
	};
}

/**
 * sending CodyResponseType.SyncRequired request to cody triggering the sync of all nodes
 * returns promise
 */
export async function syncNodes() {
	return {
		cody: 'Synchronizing Nodes.',
		type: CodyResponseType.SyncRequired,
	};
}

/**
 * Splits a message into command, prompt, and parameter.
 * @param {string} message - The message to split.
 * @returns {Promise<{ command: string; prompt: string; parameter: string }>} An object containing the command, prompt, and parameter.
 */
export function splitMessage(message: string): { command: string; prompt: string; parameter: string } {
	const aiRegex = /"([^"]*)"/;
	const commandRegex = /^(\/\w+)/;
	const parameterRegex = /-(\w+)/g;

	let promptMatch = message.match(aiRegex);
	let paramMatch = message.match(parameterRegex);
	let commandMatch = message.match(commandRegex);

	if (promptMatch && commandMatch && paramMatch) {
		return {
			command: commandMatch[0],
			prompt: promptMatch[1],
			parameter: paramMatch[0],
		};
	} else if (promptMatch && commandMatch) {
		return {
			command: commandMatch[0],
			prompt: promptMatch[1],
			parameter: '',
		};
	} else if (commandMatch && paramMatch) {
		return {
			command: commandMatch[0],
			prompt: '',
			parameter: paramMatch[0],
		};
	} else if (commandMatch) {
		return {
			command: commandMatch[0],
			prompt: '',
			parameter: '',
		};
	}

	return { command: '', prompt: '', parameter: '' };
}

/**
 * returns the codyAnswer string for handing back information of the process called for cody-response
 */
export function getCodyAnswer(): string {
	return codyAnswer;
}

/**
 * sets the codyAnswer string for handing back information of the process called for cody-response
 * @param addition
 */
export function setCodyAnswer(addition: string) {
	codyAnswer += addition;
}

/**
 * resets the codyAnswer string for handing back information of the process called for cody-response
 */
export function resetCodyAnswer() {
	codyAnswer = '';
}
