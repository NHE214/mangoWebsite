import { AiError } from './AiError';

export class AiResponseParsingError extends AiError {
	constructor(message: string) {
		super(message);
		this.name = 'AiResponseParsingError';
		Error.captureStackTrace(this, AiResponseParsingError);
	}
}
