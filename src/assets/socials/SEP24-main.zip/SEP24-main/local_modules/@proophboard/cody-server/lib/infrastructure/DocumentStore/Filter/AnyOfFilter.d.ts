import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';
export declare class AnyOfFilter implements Filter {
    readonly prop: string;
    readonly valList: any[];
    constructor(prop: string, valList: any[]);
    processWith(processor: FilterProcessor): any;
}
