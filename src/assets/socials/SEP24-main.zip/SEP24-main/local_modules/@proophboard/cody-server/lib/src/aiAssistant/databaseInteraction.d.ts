/**
 * Tests the availability of the MongoDB database.
 * @returns {Promise<boolean>} A promise that resolves with a boolean indicating database availability.
 */
export declare function testDBAvailability(): Promise<boolean>;
/**
 * Saves the ongoing conversation to the posgres database.
 * @returns {Promise<void>} A promise that resolves once the conversation is saved.
 */
export declare function saveConversationToDB(): Promise<void>;
/**
 * Retrieves the conversation history from the posgres database.
 * @returns {Promise<string>} A promise that resolves with the formatted conversation history.
 */
export declare function getConversationHistory(): Promise<string>;
/**
 * Deletes all conversation histories from the posgres database.
 * @returns {Promise<void>} A promise that resolves once all conversation histories are deleted.
 */
export declare function deleteAllConversations(): Promise<void>;
/**
 * Loads a specific conversation from the conversation history.
 * @param {number} index - The index of the conversation to load.
 * @returns {Promise<any>} A promise that resolves with the conversation data.
 */
export declare function loadConversationHistory(index: number): Promise<any>;
