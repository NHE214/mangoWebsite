import { IndexProcessor } from '../IndexProcessor';
import { FieldIndex } from '../Index/FieldIndex';
import { Index } from '../Index';
import { MultiFieldIndex } from '../Index/MultiFieldIndex';
import { MetadataFieldIndex } from '../Index/MetadataFieldIndex';
export declare class PostgresIndexProcessor implements IndexProcessor {
    process(index: Index, tableName: string): string;
    processFieldIndex(index: FieldIndex, tableName: string): string;
    processMultiFieldIndex(index: MultiFieldIndex, tableName: string): string;
    processMetadataFieldIndex(index: MetadataFieldIndex, tableName: string): string;
    private extractSortFlag;
    private extractFieldPart;
    private propToJsonPath;
}
