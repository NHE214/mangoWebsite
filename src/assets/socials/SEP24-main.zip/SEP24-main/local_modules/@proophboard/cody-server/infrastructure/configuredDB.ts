import {DB} from "./Postgres/DB";
import {Pool} from "pg";
import {env} from "../environments/environment.current";

let db: DB;

export const getConfiguredDB = (): DB => {
  if(!db) {
    db = new DB(new Pool(env.postgres))
  }

  return db;
}
