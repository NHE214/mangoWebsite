export interface Filesystem {
    existsSync: (filename: string) => boolean;
    writeFileSync: (filename: string, content: string) => void;
}
export declare class NodeFilesystem implements Filesystem {
    private nodeFs;
    constructor();
    existsSync(filename: string): boolean;
    writeFileSync(filename: string, content: string): void;
}
