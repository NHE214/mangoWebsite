export declare const asyncIteratorToArray: <T>(iter: AsyncIterable<T>) => Promise<T[]>;
