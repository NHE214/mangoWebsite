import { checkType } from '../cardHandler';
import { CodyTypeError } from '../errorHandling/ErrorTypes/HandleCardError';

describe('test checkType function', () => {
	const acceptedTypes = [
		'event',
		'document',
		'role',
		'aggregate',
		'hotSpot',
		'externalSystem',
		'ui',
		'boundedContext',
	];

	it('should throw CodyTypeError for invalid elementType', () => {
		const invalidElementType = 'invalidType';

		// Use Jest's expect().toThrow() to check for thrown errors
		expect(() => checkType(invalidElementType)).toThrow(CodyTypeError);
	});

	it('should throw CodyTypeError with correct error message', () => {
		const invalidElementType = 'invalidType';

		// Use Jest's expect().toThrowError() to check for thrown errors and their messages
		expect(() => checkType(invalidElementType)).toThrowError(
			new CodyTypeError(`${invalidElementType.toLowerCase()}`)
		);
	});

	it('should handle different valid inputs correctly', () => {
		// Test with valid inputs
		expect(checkType('domain-event')).toBe('event');
		expect(checkType('Information')).toBe('document');
		expect(checkType('actor')).toBe('role');
		expect(checkType('business rule')).toBe('aggregate');
		expect(checkType('hot-spot')).toBe('hotSpot');
		expect(checkType('External System')).toBe('externalSystem');
		expect(checkType('UI / API')).toBe('ui');
		expect(checkType('bounded context')).toBe('boundedContext');
	});
});
