import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';
export declare class LtFilter implements Filter {
    readonly prop: string;
    readonly val: any;
    constructor(prop: string, val: any);
    processWith(processor: FilterProcessor): any;
}
