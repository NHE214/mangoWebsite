export declare function asyncMap<T, M>(iter: AsyncIterable<M>, map: (item: M, index: number) => T): AsyncIterable<T>;
