import { SortOrder } from '../DocumentStore';
export declare function getValueFromPath<V = any>(path: string, doc: object, defaultValue?: V): V | undefined;
export declare const areValuesEqualForAllSorts: (sorting: SortOrder, a: object, b: object) => boolean;
