export declare type ProophAPICredentials = {
    boardId: string;
    secret: string;
};
