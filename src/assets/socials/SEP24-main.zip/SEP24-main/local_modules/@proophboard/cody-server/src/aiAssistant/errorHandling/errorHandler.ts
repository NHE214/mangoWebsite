import { CodyResponse, CodyResponseType } from '@proophboard/cody-types';
import { DatabaseError } from 'pg';
import {
	AiCredentialsError,
	AiError,
	AiOverloadError,
	AiRequestError,
	AiResponseError,
	AiTimeoutError,
	GetMetaDataError,
	PromptGenerationError,
} from './ErrorTypes/AiError';
import {
	CardNotFoundError,
	CardPositioningError,
	CodyTypeError,
	HandleCardError,
	MetadataError,
	NodeParameterError,
	ProophboardAPICredentialsError,
	ProophboardAPIError,
	RelativeDirectionError,
} from './ErrorTypes/HandleCardError';
import { AiResponseParsingError } from './ErrorTypes/AiResponseParsingError';
import { CommandError, CommandNotFoundError } from './ErrorTypes/CommandError';
import { MissingBoardIdError, SyncError } from './ErrorTypes/SyncError';

/**
 * Handles errors thrown during AI or MongoDB operations and returns an appropriate error response.
 * @param {Error} error - The error object to be handled.
 * @returns {Object} An object containing error information suitable for communication with the user interface.
 * @throws {Error} Throws the original error if it doesn't match known error ErrorTypes.
 */
export function errorHandler(error: Error): CodyResponse {
	console.error(error);
	switch (true) {
		case error instanceof CommandError:
			if (error instanceof CommandNotFoundError) {
				return {
					cody: `Can't process provided command`,
					details: `Command: ${error.message}`,
					type: CodyResponseType.Error,
				};
			} else {
				return {
					cody: `Unknown Command Error`,
					type: CodyResponseType.Error,
				};
			}
		case error instanceof DatabaseError:
			if (error instanceof DatabaseError && error.code == 'ECONNREFUSED') {
				return {
					cody: 'Error connecting to PostgreSQL server',
					details: 'Check port configuration of your PostgreSQL instance.',
					type: CodyResponseType.Error,
				};
			} else {
				return {
					cody: 'Unknown error requesting PostgreSQL server. Look at the details.',
					details: error.message,
					type: CodyResponseType.Error,
				};
			}
		case error instanceof AiError:
			if (error instanceof AiTimeoutError) {
				return {
					cody: `AI request took to much time (${error.message}) and a timeout occurred.`,
					details: 'Your AI may be overloaded. Check the length of your history.',
					type: CodyResponseType.Error,
				};
			}
			if (error instanceof AiRequestError) {
				if (error instanceof AiCredentialsError) {
					return {
						cody: `Seems like your AI credentials are wrong. Check your API key.`,
						details: `Response status: ${error.message}`,
						type: CodyResponseType.Error,
					};
				} else if (error instanceof AiOverloadError) {
					return {
						cody: `Your AI is currently overloaded. Wait a little bit or reduce the AI's effort by clearing your history.`,
						details: `Response status: ${error.message}\n
						To clear your history type /exit or /end in command line.`,
						type: CodyResponseType.Error,
					};
				} else {
					return {
						cody: `Couldn't request AI. Check availability.`,
						details: `More Information: ${error.message}`,
						type: CodyResponseType.Error,
					};
				}
			}
			if (error instanceof AiResponseParsingError) {
				return {
					cody: `Couldn't parse AI response cause response is in a wrong format`,
					details: `More Information: ${error.message}`,
					type: CodyResponseType.Error,
				};
			}
			if (error instanceof AiResponseError) {
				return {
					cody: `Something's wrong with the AI response.`,
					details: `More Information: ${error.message}`,
					type: CodyResponseType.Error,
				};
			}
			if (error instanceof PromptGenerationError) {
				if (error instanceof GetMetaDataError) {
					return {
						cody: `Couldn't get metadata templates to generate prompt.`,
						details: `reason: ${error.message}`,
						type: CodyResponseType.Error,
					};
				}
				return {
					cody: `Couldn't generate AI prompt.`,
					details: `reason: ${error.message}`,
					type: CodyResponseType.Error,
				};
			} else {
				return {
					cody: 'Unknown AI error occurred.',
					details: `More Information: ${error.message}`,
					type: CodyResponseType.Error,
				};
			}
		case error instanceof HandleCardError:
			if (error instanceof MetadataError) {
				return {
					cody: `Couldn't create Metadata.`,
					details: `More Information: ${error.message}`,
					type: CodyResponseType.Error,
				};
			}
			if (error instanceof CardNotFoundError) {
				return {
					cody: `Couldn't find a needed card. Maybe Sync didn't work?`,
					details: `More Information: ${error.message}`,
					type: CodyResponseType.Error,
				};
			}
			if (error instanceof CardPositioningError) {
				return {
					cody: 'Error positioning card on board',
					details: `More Information: ${error.message}`,
					type: CodyResponseType.Error,
				};
			}
			if (error instanceof ProophboardAPIError) {
				if (error instanceof ProophboardAPICredentialsError) {
					return {
						cody: 'Seems like your ProophboardAPICredentials are wrong. Check if your secret is right.',
						details: `Response status: ${error.message} \n To check if your secret is right, just go to the .env file in the root folder of your app.`,
						type: CodyResponseType.Error,
					};
				} else {
					return {
						cody: 'Tried to add, connect or change cards but failed cause of fetch failure from ProophboardAPI.',
						details: `More Information: ${error.message}`,
						type: CodyResponseType.Error,
					};
				}
			}
			if (error instanceof NodeParameterError) {
				if (error instanceof CodyTypeError) {
					return {
						cody: "The AI provided card types, that doesn't exist. Sorry but you have to try again.",
						details: `Provided Type: ${error.message}`,
						type: CodyResponseType.Error,
					};
				}
				if (error instanceof RelativeDirectionError) {
					return {
						cody: 'Wrong direction',
						type: CodyResponseType.Error,
					};
				}
				return {
					cody: 'Card doesnt exist',
					details: error.message,
					type: CodyResponseType.Error,
				};
			} else {
				return {
					cody: 'Card handling failed.',
					details: `More Information: ${error.message}`,
					type: CodyResponseType.Error,
				};
			}
		case error instanceof SyncError:
			if (error instanceof MissingBoardIdError) {
				return {
					cody: "Couldn't find your board id. Did you trigger a card to sync your id?",
					details: `You have to trigger a card to provide your board id. Just right click a random card and choose TriggerCody in the dropdown. If you don't have any cards yet, just create one and delete it afterwards.`,
					type: CodyResponseType.Error,
				};
			} else {
				return {
					cody: 'Unknown Sync Error',
					details: `More Information: ${error.message}`,
					type: CodyResponseType.Error,
				};
			}
		case error instanceof PromptGenerationError:

		default:
			console.log('Default error');
			throw error;
	}
}
