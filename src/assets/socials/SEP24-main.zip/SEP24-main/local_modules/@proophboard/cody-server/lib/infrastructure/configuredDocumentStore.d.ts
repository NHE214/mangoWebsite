import { DocumentStore } from "./DocumentStore";
export declare const PERSISTENT_COLLECTION_FILE: string;
export declare const getConfiguredDocumentStore: () => DocumentStore;
