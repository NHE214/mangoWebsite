import { Environment } from './environment.schema';
export declare const env: Environment;
