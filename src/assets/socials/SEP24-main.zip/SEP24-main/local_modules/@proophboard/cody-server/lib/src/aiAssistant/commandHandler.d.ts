import { CodyResponse, CodyResponseType } from '@proophboard/cody-types';
export declare enum Commands {
    test = "/test",
    exit = "/exit",
    end = "/end",
    ai = "/ai",
    suggest = "/suggest",
    tip = "/tip",
    hotSpots = "/hotSpots",
    flows = "/flows",
    events = "/events",
    history = "/history",
    delete = "/delete",
    create = "/create",
    createPlus = "/createPlus",
    multiCreate = "/multiCreate",
    sync = "/sync",
    metaData = "/metaData"
}
/**
 * Handles user commands.
 * @param {string} repl - The user's input.
 * @returns {Promise<CodyResponse>} The Cody-Response, depending on the command sent.
 */
export declare function handleCommand(repl: string): Promise<CodyResponse>;
/**-
 * Function to handle chat mode.
 * @param {string} prompt - The prompt for the chat mode.
 * @returns {Promise<any>} A promise resolving to the response.
 */
export declare function chatMode(prompt: string): Promise<any>;
/**
 * prints alls cards contained in syncedNodes
 */
export declare function printSynchronizedNodesToConsole(): Promise<{
    cody: string;
    type: CodyResponseType;
    reply: (userReply: string) => Promise<CodyResponse>;
}>;
/**
 * sending CodyResponseType.SyncRequired request to cody triggering the sync of all nodes
 * returns promise
 */
export declare function syncNodes(): Promise<{
    cody: string;
    type: CodyResponseType;
}>;
/**
 * Splits a message into command, prompt, and parameter.
 * @param {string} message - The message to split.
 * @returns {Promise<{ command: string; prompt: string; parameter: string }>} An object containing the command, prompt, and parameter.
 */
export declare function splitMessage(message: string): {
    command: string;
    prompt: string;
    parameter: string;
};
/**
 * returns the codyAnswer string for handing back information of the process called for cody-response
 */
export declare function getCodyAnswer(): string;
/**
 * sets the codyAnswer string for handing back information of the process called for cody-response
 * @param addition
 */
export declare function setCodyAnswer(addition: string): void;
/**
 * resets the codyAnswer string for handing back information of the process called for cody-response
 */
export declare function resetCodyAnswer(): void;
