import { getCodyConfig } from '../http/question';
import { API_KEY } from './config';
import {
	CardNotFoundError,
	CardPositioningError,
	CodyTypeError,
	NodeParameterError,
	ProophboardAPICredentialsError,
	ProophboardAPIError,
} from './errorHandling/ErrorTypes/HandleCardError';
import { GraphPoint, NodeName } from '@proophboard/cody-types';
import { CardsWithoutPositionList, CardsWithPositionList, proophBoardAPIRequest } from './types';

//TODO: combine positioning functions

enum ProophboardOperation {
	addElementAtPosition = 'add-element-at-position',
	addElementNextToAnother = 'add-element-next-to-another',
	connectElements = 'connect-elements',
	changeElementMetaData = 'change-element-metadata',
}

export enum CardTypes {
	Event = 'event',
	Command = 'command',
	Role = 'role',
	Aggregate = 'aggregate',
	Document = 'document',
	Policy = 'policy',
	HotSpot = 'hotSpot',
	ExternalSystem = 'externalSystem',
	UI = 'ui',
	Feature = 'feature',
	BoundedContext = 'boundedContext',
	FreeText = 'freeText',
	Edge = 'edge',
	Misc = 'misc',
	Icon = 'icon',
	Image = 'image',
	Layer = 'layer',
}

async function fetchFromProophboard(operation: string, requestBody: proophBoardAPIRequest): Promise<void> {
	const config = await getCodyConfig();
	const url = `https://app.prooph-board.com/board/api/v1/board-agent/${config.context.boardId}/tasks/${operation}`;
	let response;
	try {
		response = await fetch(url, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'X-Auth-Secret': API_KEY,
			},
			body: JSON.stringify(requestBody),
		});
	} catch (error) {
		throw new ProophboardAPIError('Fetch from Proophboard failed.');
	}
	if (response.status === 202) {
		console.log('Element added successfully.');
	} else if (!response.ok) {
		console.log(response);
		if (response.status === 401) {
			throw new ProophboardAPICredentialsError(`${response.statusText}`);
		}
		throw new ProophboardAPIError(`Operation: ${operation}, Response status: ${response.statusText}`);
	}
}

/**
 * generates a randomId for adding new Elements
 * Generates a random UUID v4.
 * @returns {string} A random UUID v4.
 */
function generateRandomId(): string {
	const randomHex = (): string => Math.floor(Math.random() * 16).toString(16);

	const segments: string[] = [
		randomHex() + randomHex() + randomHex() + randomHex(),
		randomHex() + randomHex(),
		randomHex() + randomHex(),
		randomHex() + randomHex(),
		randomHex() + randomHex() + randomHex() + randomHex() + randomHex() + randomHex(),
	];

	return segments.join('-');
}

/**
 * connects two cards on the board per ID
 * @param sourceElementID
 * @param targetElementID
 */
export async function connectElementsByID(sourceElementID: string, targetElementID: string): Promise<any> {
	let sourceElementId: string | undefined;
	let targetElementId: string | undefined;
	let config = await getCodyConfig();

	config.context.syncedNodes.forEach(node => {
		if (node.getId() === targetElementID) {
			targetElementId = node.getId();
		} else if (node.getId() === sourceElementID) {
			sourceElementId = node.getId();
		}
	});
	const requestBody: proophBoardAPIRequest = {
		source: sourceElementId,
		target: targetElementId,
		boardId: config.context.boardId,
	};
	await fetchFromProophboard(ProophboardOperation.connectElements, requestBody);
}

/**
 * changes card position for as long as isPositionBLocked() returns true
 * @param wantedPosition
 */
async function changePosition(wantedPosition: GraphPoint) {
	while (await isPositionBlocked(wantedPosition)) {
		wantedPosition = {
			x: wantedPosition.x + 240,
			y: wantedPosition.y,
		};
	}
	return wantedPosition;
}

/**
 * checking if position parameters exist in given (wantedPosition) combination
 * @param wantedPosition
 */
async function isPositionBlocked(wantedPosition: GraphPoint) {
	let config = await getCodyConfig();
	try {
		let wasBlocked = false;
		config.context.syncedNodes.forEach(node => {
			if (wantedPosition.x === node.getGeometry().x && wantedPosition.y === node.getGeometry().y) {
				wasBlocked = true;
			}
		});
		return wasBlocked;
	} catch (error) {
		throw new CardPositioningError("Couldn't check if wanted position is available.");
	}
}

export async function addMetaData(targetElementId: string, metaData: string): Promise<void> {
	const config = await getCodyConfig();
	const requestBody: proophBoardAPIRequest = {
		elementId: targetElementId,
		boardId: config.context.boardId,
		metadata: metaData,
	};

	await fetchFromProophboard(ProophboardOperation.changeElementMetaData, requestBody);
}

/**
 * Connects two elements on the board.
 * @param {string} sourceElementId - The content of the source element.
 * @param {string} targetElementId - The content of the target element.
 */
export async function connectElements(sourceElementId: string, targetElementId: string): Promise<void> {
	let config = await getCodyConfig();
	config.context.syncedNodes.forEach(node => {
		console.log(`name: ${node.getName()}, id: ${node.getId()}`);
		if (node.getName().toLowerCase() === targetElementId.toLowerCase()) {
			targetElementId = node.getId();
			console.log('Target found');
		} else if (node.getName().toLowerCase() === sourceElementId.toLowerCase()) {
			sourceElementId = node.getId();
			console.log('Source found');
		}
	});

	if (sourceElementId && targetElementId) {
		const requestBody: proophBoardAPIRequest = {
			source: sourceElementId,
			target: targetElementId,
			boardId: config.context.boardId,
		};

		await fetchFromProophboard(ProophboardOperation.connectElements, requestBody);
	} else {
		throw new NodeParameterError(`${sourceElementId} or ${targetElementId}`);
	}
}

/**
 * adds an Element at the given position
 * @param position
 * @param elementType
 * @param name
 */
export async function addElementAtPosition(position: GraphPoint, elementType: string, name: string) {
	let config = await getCodyConfig();
	const elementId = generateRandomId();
	const type = checkType(elementType);
	let elementParent;
	config.context.syncedNodes.forEach((node: { getParent: () => any }) => {
		elementParent = node.getParent();
	});
	const parent = JSON.stringify(elementParent);

	const requestBody: proophBoardAPIRequest = {
		elementId: elementId,
		boardId: config.context.boardId,
		type: type,
		name: name,
		content: '',
		position: position,
		parent: parent,
	};

	await fetchFromProophboard(ProophboardOperation.addElementAtPosition, requestBody);
}

/**
 *
 * @param sourceElementID
 * @param name
 * @param elementType
 * @param direction
 */
export async function addCardNextId(
	sourceElementID: string,
	name: string,
	elementType: string,
	direction: string = 'right'
) {
	let config = await getCodyConfig();
	let sourceId: string = '';
	let sourceParent: any;
	config.context.syncedNodes.forEach(node => {
		if (node.getId() === sourceElementID) {
			sourceId = node.getId();
			sourceParent = node.getParent();
		}
	});

	const elementId: string = generateRandomId();
	const nextToElementId: any = sourceId;
	const type: string = checkType(elementType);
	const content: string = '';
	const parent: string = JSON.stringify(sourceParent);
	const margin: number = 120;
	const requestBody: proophBoardAPIRequest = {
		elementId: elementId,
		boardId: config.context.boardId,
		nextToElementId: nextToElementId,
		type: type,
		name: name,
		content: content,
		position: direction,
		parent: parent,
		margin: margin,
	};
	await fetchFromProophboard(ProophboardOperation.addElementNextToAnother, requestBody);
	return elementId;
}

/**
 *
 * @param name
 * @param elementType
 * @param offset
 */
export async function addCardExtended(
	name: string,
	elementType: string,
	offset: GraphPoint = {
		x: 0,
		y: 0,
	}
) {
	let position: GraphPoint = offset;
	position = await changePosition(position);
	const config = await getCodyConfig();
	const elementId = generateRandomId();
	const type = checkType(elementType);
	const content: string = '';
	/* !!! important !!!
	 * the hard-coded parent string currently has to be replaced by your own root parent,
	 */
	const parent: string =
		'{"id":"7fe80d19-d317-4e9d-8296-96c598786d78","name":"Board","description":"","type":"layer","link":"","tags":[],"layer":true,"defaultLayer":true,"parent":null,"childrenList":[],"sourcesList":[],"targetsList":[],"geometry":{"x":0,"y":0},"metadata":null}';

	let metadata: string = '';
	let size = { width: 160, height: 100 };
	const requestBody: proophBoardAPIRequest = {
		elementId: elementId,
		boardId: config.context.boardId,
		type: type,
		name: name,
		content: content,
		position: position,
		parent: parent,
		metadata: metadata,
		size: size,
	};

	console.log(requestBody);
	await fetchFromProophboard(ProophboardOperation.addElementAtPosition, requestBody);
	return elementId;
}

export function checkType(elementType: string): string {
	let targetElementType: CardTypes;
	elementType = elementType.toLowerCase().replace(/[-_ ]/g, '');
	elementType = elementType.toLowerCase().replace(/list/g, '');
	elementType = elementType.toLowerCase().replace(/card/g, '');
	switch (elementType) {
		case 'domainevent':
			targetElementType = CardTypes.Event;
			break;
		case 'information':
			targetElementType = CardTypes.Document;
			break;
		case 'actor':
			targetElementType = CardTypes.Role;
			break;
		case 'businessrule':
			targetElementType = CardTypes.Aggregate;
			break;
		case 'hotspot':
			targetElementType = CardTypes.HotSpot;
			break;
		case 'externalsystem':
			targetElementType = CardTypes.ExternalSystem;
			break;
		case 'ui/api':
			targetElementType = CardTypes.UI;
			break;
		case 'boundedcontext':
			targetElementType = CardTypes.BoundedContext;
			break;
		case 'object':
			targetElementType = CardTypes.Document;
			break;
		default:
			targetElementType = elementType as CardTypes;
	}
	if (!Object.values(CardTypes).includes(targetElementType)) {
		throw new CodyTypeError(`${targetElementType}`);
	}
	return targetElementType;
}

/**
 * get the card name by its ID
 * @param cardId
 */
export async function getNameById(cardId: string): Promise<NodeName> {
	const config = await getCodyConfig();
	let name = '';
	config.context.syncedNodes.forEach(node => {
		if (node.getId() === cardId) {
			name = node.getName();
		}
	});
	if (name != '') {
		return name;
	} else {
		throw new CardNotFoundError(`Tried to get the name of a card with the id ${cardId}.`);
	}
}

export function adjustPosition(cards: CardsWithoutPositionList, position: GraphPoint): CardsWithPositionList {
	let eventListWithPositions: CardsWithPositionList = { cards: [{ name: '', geometry: { x: 0, y: 0 }, type: '' }] };
	let rows: number[] = [0, 0, 0, 0];
	let type = '';

	for (const v of cards.cards) {
		type = checkType(v.type);
		switch (type) {
			case 'event':
				eventListWithPositions.cards.push({
					geometry: { x: position.x + rows[3] * 200, y: position.y },
					name: v.name,
					type: type,
				});
				rows[3]++;
				break;
			case 'command':
				eventListWithPositions.cards.push({
					geometry: { x: position.x + rows[1] * 200, y: position.y - 300 },
					name: v.name,
					type: type,
				});
				rows[1]++;
				break;
			case 'role':
				eventListWithPositions.cards.push({
					geometry: { x: position.x - 300, y: position.y - 600 },
					name: v.name,
					type: type,
				});
				break;
			case 'aggregate':
				eventListWithPositions.cards.push({
					geometry: { x: position.x + rows[2] * 200, y: position.y - 150 },
					name: v.name,
					type: type,
				});
				rows[2]++;
				break;
			case 'document':
				eventListWithPositions.cards.push({
					geometry: { x: position.x + rows[1] * 200, y: position.y - 300 },
					name: v.name,
					type: type,
				});
				rows[1]++;
				break;
			case 'hotSpot':
				eventListWithPositions.cards.push({
					geometry: { x: position.x + rows[3] * 200, y: position.y },
					name: v.name,
					type: type,
				});
				rows[3]++;
				break;
			case 'externalSystem':
				eventListWithPositions.cards.push({
					geometry: { x: position.x + rows[0] * 200, y: position.y - 600 },
					name: v.name,
					type: type,
				});
				rows[0]++;
				break;
			case 'ui':
				eventListWithPositions.cards.push({
					geometry: { x: position.x + rows[0] * 200, y: position.y - 600 },
					name: v.name,
					type: type,
				});
				rows[0]++;
				break;
			default:
				eventListWithPositions.cards.push({
					geometry: { x: position.x, y: position.y - 900 },
					name: v.name,
					type: type,
				});
		}
		console.log(rows, 'rows------------------');
	}
	eventListWithPositions.cards.shift();
	return eventListWithPositions;
}
