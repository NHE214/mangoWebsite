export declare const asyncEmptyIterator: <T>() => AsyncIterable<T>;
