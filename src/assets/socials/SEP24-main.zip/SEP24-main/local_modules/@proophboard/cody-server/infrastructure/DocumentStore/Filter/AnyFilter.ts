import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';

export class AnyFilter implements Filter {
	processWith(processor: FilterProcessor): any {
		return processor.processAnyFilter(this);
	}
}
