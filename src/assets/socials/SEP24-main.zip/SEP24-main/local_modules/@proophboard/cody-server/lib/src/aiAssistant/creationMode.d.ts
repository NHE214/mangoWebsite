import { GraphPoint } from '@proophboard/cody-types';
export declare enum SystemOperations {
    add = "add",
    edit = "edit",
    delete = "delete"
}
/**
 * parses value pairs name/type for suggested cards and creates system by calling cardHandler.ts
 * additionally connects cards by order (given in primerText) and adds metadata according to type
 * @param response
 * @param offset
 */
export declare function systemCreate(response: string, offset?: GraphPoint): Promise<void>;
/**
 * waits for a given amount of time in ms (or defaults to 1000ms)
 * @param time
 */
export declare function buyingTime(time?: number): Promise<unknown>;
/**
 * create all 3 system add,delete,edit for a single input sentence
 * @param response
 */
export declare function eventsCreate(response: string): Promise<void>;
/**
 * create systems of add,delete,edit for various AI suggested entities
 * @param response
 */
export declare function eventsMultiCreate(response: string): Promise<void>;
