import { IndexProcessor } from '../IndexProcessor';
import { Sort } from '../../DocumentStore';
import { Index } from '../Index';
declare type MultiFieldIndexFields = Array<{
    field: string;
    sort?: Sort;
}>;
export declare class MultiFieldIndex implements Index {
    readonly name: string;
    readonly fields: MultiFieldIndexFields;
    readonly unique?: boolean;
    static forFields(name: string, fields: string[], unique?: boolean): MultiFieldIndex;
    static forFieldsWithSort(name: string, fields: MultiFieldIndexFields, unique?: boolean): MultiFieldIndex;
    private constructor();
    processWith(indexProcessor: IndexProcessor, tableName: string): any;
}
export {};
