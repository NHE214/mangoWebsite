// Import necessary modules and ErrorTypes
import { ReplyCallback } from './response';
import { CodyResponse, CodyResponseType } from '@proophboard/cody-types';
import { handleCommand } from '../aiAssistant/commandHandler'; // Importing the reply function from messageHandler
import { CodyConfig } from '../config/codyconfig';
import { MissingBoardIdError } from '../aiAssistant/errorHandling/ErrorTypes/SyncError';

export interface Reply {
	reply: any;
}

let codyConfig: CodyConfig;

async function setCodyConfig() {
	return {
		cody: 'Syncing',
		type: CodyResponseType.SyncRequired,
	};
}

export async function getCodyConfig() {
	await setCodyConfig();
	if (codyConfig.context.boardId === '') {
		throw new MissingBoardIdError('empty board id');
	}
	return codyConfig;
}

/**
 * Represents the current question callback.
 * @type {ReplyCallback|undefined}
 */
let CurrentQuestion: ReplyCallback | undefined;

/**
 * Represents a reply object.
 * @interface Reply
 * @property {any} handleCommand - The reply content.
 */

/**
 * Checks if the response is a question and stores its reply callback.
 * @param {CodyResponse} res - The Cody response object.
 * @returns {CodyResponse} The modified Cody response object.
 */
export const checkQuestion = (res: CodyResponse): CodyResponse => {
	if (res.type === CodyResponseType.Question && res.reply) {
		CurrentQuestion = res.reply;
	}

	return res;
};

/**
 * Handles replies to the current question.
 * @param {any} reply - The user's reply.
 * @returns {Promise<CodyResponse>} The response to the user's reply.
 */
export const handleReply = async (reply: any): Promise<CodyResponse> => {
	if (CurrentQuestion) {
		const res = await CurrentQuestion(reply);
		CurrentQuestion = undefined; // Reset the current question callback
		return res;
	}

	// If there's no current question, return a default response
	return {
		cody: 'Sorry, not sure what to say.',
		details: 'Did I ask anything?',
		type: CodyResponseType.Warning,
	};
};

/**
 * Handles the users reply after the /talk command.
 * From there on, our own reply-function takes over.
 * @param {CodyConfig} config - The configuration object.
 * @returns {CodyResponse} - The prompt, that gives the user our commands as options.
 */
export const test = (config: CodyConfig): CodyResponse => {
	codyConfig = config;
	return {
		cody: 'What would you like to do?',
		details:
			'Type /ai -chat to start the chatbot or send a single message with /ai -m "*Your Message*"\nType /end or /exit to exit' +
			'/addElement to add a card, /connect to connect two cards,\n /tip for ai help with event storming, /flows for ai help with flows.' +
			'\n /history to view all ai interactions and maybe select a context /delete to delete all ai conversation history.',
		type: CodyResponseType.Question,
		// Include a reply callback to handle user input
		reply: async (yes: string): Promise<CodyResponse> => {
			return handleCommand(yes); // Call the reply function from messageHandler
		},
	};
};
