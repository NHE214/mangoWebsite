import { Filter } from '../Filter';
import { FilterProcessor } from '../FilterProcessor';

export class LikeFilter implements Filter {
	public readonly prop: string;
	public readonly val: any;

	constructor(prop: string, val: any) {
		this.prop = prop;
		this.val = val;
	}

	processWith(processor: FilterProcessor): any {
		return processor.processLikeFilter(this);
	}
}
