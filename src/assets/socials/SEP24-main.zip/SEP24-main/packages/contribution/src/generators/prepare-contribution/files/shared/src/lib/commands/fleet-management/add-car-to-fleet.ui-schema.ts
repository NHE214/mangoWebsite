import {UiSchema} from "@rjsf/utils";

export const AddCarToFleetUiSchema: UiSchema = {
  "vehicleId": {
    "ui:widget": "hidden"
  }
}
