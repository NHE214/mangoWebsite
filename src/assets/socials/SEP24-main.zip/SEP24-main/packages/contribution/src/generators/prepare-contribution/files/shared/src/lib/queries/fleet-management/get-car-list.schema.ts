export const GetCarListSchema = {
  "type": "object",
  "properties": {},
  "required": [],
  "additionalProperties": false
} as const;
