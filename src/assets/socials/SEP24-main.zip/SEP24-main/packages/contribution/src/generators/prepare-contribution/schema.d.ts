export interface PrepareContributionGeneratorSchema {
}
