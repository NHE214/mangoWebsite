export const toJSON = (val: any): string => {
  return JSON.stringify(val, null, 2);
}
