export const now = (): string => {
  return (new Date()).toISOString();
}
