export class ConcurrencyError extends Error {}
