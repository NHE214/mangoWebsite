import { getJestProjects } from '@nx/jest';

export default {
	projects: [...getJestProjects(), '<rootDir>/local_modules/@proophboard/cody-server/jest.config.cody-server.ts'],
};
